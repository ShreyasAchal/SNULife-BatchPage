import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/Navbar';
import { 
  Calendar, ChevronLeft, ChevronRight, Eye, EyeOff,
  Filter, FolderClosed, Search, X, ChevronDown, ChevronUp,
  Trash2, Edit, Plus, RefreshCw, PenLine, Folder, FolderPlus,
  ExternalLink, FileText, Image, Loader2
} from 'lucide-react';
import { 
  Card, CardContent, CardDescription, CardHeader, CardTitle 
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Pagination, PaginationContent, PaginationItem, PaginationLink } from '../components/ui/pagination';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../components/ui/collapsible';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '../components/ui/table';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage 
} from '../components/ui/form';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useToast } from '../hooks/use-toast';
import { useForm } from 'react-hook-form';
import { supabase } from '@/integrations/supabase/client';
import { v4 as uuidv4 } from 'uuid';
import CourseInstructorInfo from '@/components/course/CourseInstructorInfo';
import CourseTAInfo from '@/components/course/CourseTAInfo';
import CourseManagement from '../components/course/CourseManagement';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import CourseFileUpload from '../components/course/CourseFileUpload';
import CourseFileList from '../components/course/CourseFileList';

type PostTag = 'Assignment' | 'Reschedule' | 'Cancellation' | 'Academic' | 'Clarification' | 'Exams' | 'Quiz' | 'Others';

interface Course {
  id: string;
  code: string;
  name: string;
  folders?: Folder[];
}

interface Folder {
  id: string;
  course_id: string;
  name: string;
}

interface Post {
  id: string;
  tag: PostTag;
  title: string;
  poster: string;
  content: string;
  course_id?: string;
  course?: string; // This is the display version, constructed from DB data
  created_at: string;
  updated_at: string; 
  isRead?: boolean;
}

interface Deadline {
  id: string;
  title: string;
  course_id?: string;
  course?: string; // This is the display version, constructed from DB data
  due_date: string;
  due_time: string;
  tag: PostTag;
  completed?: boolean;
}

interface PostRead {
  post_id: string;
  user_id: string;
  read_at: string;
}

const tagColors: Record<PostTag, string> = {
  Assignment: 'bg-amber-500',
  Reschedule: 'bg-purple-500',
  Cancellation: 'bg-red-500',
  Academic: 'bg-blue-500',
  Clarification: 'bg-green-500',
  Exams: 'bg-rose-500',
  Quiz: 'bg-cyan-500',
  Others: 'bg-gray-500'
};

const getUserId = () => {
  let userId = localStorage.getItem('community_user_id');
  if (!userId) {
    userId = uuidv4();
    localStorage.setItem('community_user_id', userId);
  }
  return userId;
};

const CommunityPage: React.FC = () => {
  const [showAllPosts, setShowAllPosts] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [expandedPosts, setExpandedPosts] = useState<string[]>([]);
  const [showCompletedDeadlines, setShowCompletedDeadlines] = useState(false);
  const [readPosts, setReadPosts] = useState<string[]>([]);
  const [isCRMode, setIsCRMode] = useState(false);
  const [isAddingPost, setIsAddingPost] = useState(false);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [activeTag, setActiveTag] = useState<PostTag | null>(null);
  const [activeCourse, setActiveCourse] = useState<string | null>(null);
  const [isAddingDeadline, setIsAddingDeadline] = useState(false);
  const [editingDeadline, setEditingDeadline] = useState<Deadline | null>(null);
  const [editingFolder, setEditingFolder] = useState<{courseId: string, folderId: string, name: string} | null>(null);
  const [newFolderName, setNewFolderName] = useState('');
  const [addingFolderToCourse, setAddingFolderToCourse] = useState<string | null>(null);
  const userId = getUserId();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { 
    data: courses = [], 
    isLoading: isLoadingCourses
  } = useQuery({
    queryKey: ['courses'],
    queryFn: async () => {
      const { data: courses, error } = await supabase
        .from('courses')
        .select('*')
        .order('code', { ascending: true });
      
      if (error) throw error;
      return courses as Course[];
    }
  });

  const { 
    data: folders = [], 
    isLoading: isLoadingFolders 
  } = useQuery({
    queryKey: ['folders'],
    queryFn: async () => {
      const { data: folders, error } = await supabase
        .from('course_folders')
        .select('*')
        .order('name', { ascending: true });
      
      if (error) throw error;
      return folders as Folder[];
    }
  });

  const {
    data: posts = [],
    isLoading: isLoadingPosts
  } = useQuery({
    queryKey: ['posts'],
    queryFn: async () => {
      const { data: posts, error } = await supabase
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const postsWithCourseInfo = await Promise.all(posts.map(async (post) => {
        if (post.course_id) {
          const { data: courseData } = await supabase
            .from('courses')
            .select('code, name')
            .eq('id', post.course_id)
            .single();
          
          if (courseData) {
            return {
              ...post,
              course: `${courseData.code}: ${courseData.name}`
            };
          }
        }
        return post;
      }));
      
      return postsWithCourseInfo as Post[];
    }
  });

  const {
    data: deadlines = [],
    isLoading: isLoadingDeadlines
  } = useQuery({
    queryKey: ['deadlines'],
    queryFn: async () => {
      const { data: deadlines, error } = await supabase
        .from('deadlines')
        .select('*')
        .order('due_date', { ascending: true });
      
      if (error) throw error;
      
      const deadlinesWithCourseInfo = await Promise.all(deadlines.map(async (deadline) => {
        if (deadline.course_id) {
          const { data: courseData } = await supabase
            .from('courses')
            .select('code, name')
            .eq('id', deadline.course_id)
            .single();
          
          if (courseData) {
            return {
              ...deadline,
              course: `${courseData.code}: ${courseData.name}`
            };
          }
        }
        return deadline;
      }));
      
      return deadlinesWithCourseInfo as Deadline[];
    }
  });

  const {
    data: postReads = [],
    isLoading: isLoadingPostReads
  } = useQuery({
    queryKey: ['postReads', userId],
    queryFn: async () => {
      const { data: reads, error } = await supabase
        .from('post_reads')
        .select('*')
        .eq('user_id', userId);
      
      if (error) throw error;
      return reads as PostRead[];
    }
  });
  
  const createPostMutation = useMutation({
    mutationFn: async (newPost: Omit<Post, 'id' | 'created_at' | 'updated_at' | 'isRead'>) => {
      const { data, error } = await supabase
        .from('posts')
        .insert({
          title: newPost.title,
          content: newPost.content,
          tag: newPost.tag,
          poster: newPost.poster,
          course_id: newPost.course_id
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      setIsAddingPost(false);
      toast({
        title: "Announcement Added",
        description: "Your announcement has been posted successfully."
      });
    }
  });

  const updatePostMutation = useMutation({
    mutationFn: async (post: Post) => {
      const { data, error } = await supabase
        .from('posts')
        .update({
          title: post.title,
          content: post.content,
          tag: post.tag,
          course_id: post.course_id
        })
        .eq('id', post.id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      setEditingPost(null);
      toast({
        title: "Announcement Updated",
        description: "Your announcement has been updated successfully."
      });
    }
  });

  const deletePostMutation = useMutation({
    mutationFn: async (postId: string) => {
      const { error } = await supabase
        .from('posts')
        .delete()
        .eq('id', postId);
      
      if (error) throw error;
      return postId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast({
        title: "Announcement Deleted",
        description: "The announcement has been removed."
      });
    }
  });

  const createDeadlineMutation = useMutation({
    mutationFn: async (newDeadline: Omit<Deadline, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('deadlines')
        .insert({
          title: newDeadline.title,
          course_id: newDeadline.course_id,
          due_date: newDeadline.due_date,
          due_time: newDeadline.due_time,
          tag: newDeadline.tag,
          completed: newDeadline.completed || false
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deadlines'] });
      setIsAddingDeadline(false);
      toast({
        title: "Deadline Added",
        description: "The new deadline has been added successfully."
      });
    }
  });

  const updateDeadlineMutation = useMutation({
    mutationFn: async (deadline: Deadline) => {
      const { data, error } = await supabase
        .from('deadlines')
        .update({
          title: deadline.title,
          course_id: deadline.course_id,
          due_date: deadline.due_date,
          due_time: deadline.due_time,
          tag: deadline.tag,
          completed: deadline.completed
        })
        .eq('id', deadline.id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deadlines'] });
      setEditingDeadline(null);
      toast({
        title: "Deadline Updated",
        description: "The deadline has been updated successfully."
      });
    }
  });

  const deleteDeadlineMutation = useMutation({
    mutationFn: async (deadlineId: string) => {
      const { error } = await supabase
        .from('deadlines')
        .delete()
        .eq('id', deadlineId);
      
      if (error) throw error;
      return deadlineId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deadlines'] });
      toast({
        title: "Deadline Deleted",
        description: "The deadline has been removed."
      });
    }
  });

  const toggleDeadlineCompletionMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      const { data, error } = await supabase
        .from('deadlines')
        .update({ completed })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deadlines'] });
    }
  });

  const createFolderMutation = useMutation({
    mutationFn: async ({ courseId, name }: { courseId: string; name: string }) => {
      const { data, error } = await supabase
        .from('course_folders')
        .insert({
          course_id: courseId,
          name
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folders'] });
      setAddingFolderToCourse(null);
      setNewFolderName('');
      toast({
        title: "Folder Added",
        description: "The new folder has been added successfully."
      });
    }
  });

  const updateFolderMutation = useMutation({
    mutationFn: async ({ folderId, name }: { folderId: string; name: string }) => {
      const { data, error } = await supabase
        .from('course_folders')
        .update({ name })
        .eq('id', folderId)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folders'] });
      setEditingFolder(null);
      toast({
        title: "Folder Renamed",
        description: "The folder has been renamed successfully."
      });
    }
  });

  const markPostAsReadMutation = useMutation({
    mutationFn: async (postId: string) => {
      const { data: existingRead } = await supabase
        .from('post_reads')
        .select('*')
        .eq('post_id', postId)
        .eq('user_id', userId)
        .single();
      
      if (existingRead) return existingRead;
      
      const { data, error } = await supabase
        .from('post_reads')
        .insert({
          post_id: postId,
          user_id: userId
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['postReads', userId] });
    }
  });
  
  useEffect(() => {
    if (postReads.length > 0) {
      setReadPosts(postReads.map(read => read.post_id));
    }
  }, [postReads]);

  useEffect(() => {
    if (selectedCourse && folders.length > 0) {
      const courseFolders = folders.filter(f => f.course_id === selectedCourse.id);
      setSelectedCourse({ ...selectedCourse, folders: courseFolders });
    }
  }, [selectedCourse, folders]);

  const togglePostExpansion = (postId: string) => {
    if (!readPosts.includes(postId)) {
      setReadPosts(prev => [...prev, postId]);
      markPostAsReadMutation.mutate(postId);
    }
    
    setExpandedPosts(prev => 
      prev.includes(postId) 
        ? prev.filter(id => id !== postId) 
        : [...prev, postId]
    );
  };

  const isPostExpanded = (postId: string) => expandedPosts.includes(postId);
  const isPostRead = (postId: string) => readPosts.includes(postId);

  const toggleMode = () => {
    setIsCRMode(!isCRMode);
    toast({
      title: `Switched to ${!isCRMode ? 'CR Mode' : 'User View'}`,
      description: `You are now in ${!isCRMode ? 'CR Mode' : 'User View'} mode.`,
    });
  };

  const handleAddPost = (newPostData: any) => {
    const courseId = courses.find(c => `${c.code}: ${c.name}` === newPostData.course)?.id;
    
    const newPost = {
      title: newPostData.title,
      content: newPostData.content,
      tag: newPostData.tag as PostTag,
      poster: 'Shreyas Achal: CR_CSE\'27',
      course_id: courseId
    };
    
    createPostMutation.mutate(newPost);
  };

  const handleEditPost = (postData: any) => {
    if (!editingPost) return;
    
    const courseId = courses.find(c => `${c.code}: ${c.name}` === postData.course)?.id;
    
    const updatedPost = {
      ...editingPost,
      title: postData.title,
      content: postData.content,
      tag: postData.tag as PostTag,
      course_id: courseId
    };
    
    updatePostMutation.mutate(updatedPost);
  };

  const handleDeletePost = (postId: string) => {
    if (window.confirm("Are you sure you want to delete this announcement?")) {
      deletePostMutation.mutate(postId);
    }
  };

  const handleAddDeadline = (newDeadlineData: any) => {
    const courseId = courses.find(c => `${c.code}: ${c.name}` === newDeadlineData.course)?.id;
    
    const newDeadline = {
      title: newDeadlineData.title,
      course_id: courseId,
      due_date: newDeadlineData.dueDate,
      due_time: newDeadlineData.dueTime,
      tag: newDeadlineData.tag as PostTag,
      completed: newDeadlineData.completed || false
    };
    
    createDeadlineMutation.mutate(newDeadline);
  };

  const handleEditDeadline = (deadlineData: any) => {
    if (!editingDeadline) return;
    
    const courseId = courses.find(c => `${c.code}: ${c.name}` === deadlineData.course)?.id;
    
    const updatedDeadline = {
      ...editingDeadline,
      title: deadlineData.title,
      course_id: courseId,
      due_date: deadlineData.dueDate,
      due_time: deadlineData.dueTime,
      tag: deadlineData.tag as PostTag,
      completed: deadlineData.completed || false
    };
    
    updateDeadlineMutation.mutate(updatedDeadline);
  };

  const handleDeleteDeadline = (deadlineId: string) => {
    if (window.confirm("Are you sure you want to delete this deadline?")) {
      deleteDeadlineMutation.mutate(deadlineId);
    }
  };

  const toggleDeadlineCompletion = (deadlineId: string, currentState: boolean) => {
    toggleDeadlineCompletionMutation.mutate({ 
      id: deadlineId, 
      completed: !currentState 
    });
  };

  const handleRenameFolder = () => {
    if (editingFolder && editingFolder.name.trim()) {
      updateFolderMutation.mutate({
        folderId: editingFolder.folderId,
        name: editingFolder.name
      });
    }
  };

  const handleAddFolder = () => {
    if (addingFolderToCourse && newFolderName.trim()) {
      createFolderMutation.mutate({
        courseId: addingFolderToCourse,
        name: newFolderName
      });
    }
  };

  const filterPostsByTag = (tag: PostTag | null) => {
    setActiveTag(tag);
    setActiveCourse(null);
  };

  const filterPostsByCourse = (course: string | null) => {
    setActiveCourse(course);
    setActiveTag(null);
  };

  const clearFilters = () => {
    setActiveTag(null);
    setActiveCourse(null);
  };

  const filteredPosts = posts.filter(post => {
    if (activeTag && post.tag !== activeTag) return false;
    if (activeCourse && post.course !== activeCourse) return false;
    return true;
  });

  const visiblePosts = showAllPosts ? filteredPosts : filteredPosts.slice(0, 3);

  const activeDeadlines = deadlines.filter(d => !d.completed);
  const completedDeadlines = deadlines.filter(d => d.completed);
  const displayedDeadlines = showCompletedDeadlines ? completedDeadlines : activeDeadlines;

  const AnnouncementPost: React.FC<{ post: Post }> = ({ post }) => {
    return (
      <Collapsible 
        key={post.id} 
        open={isPostExpanded(post.id)} 
        onOpenChange={() => togglePostExpansion(post.id)}
        className="w-full mb-3"
      >
        <Card className="bg-dark-surface border-dark-border w-full hover:border-white/30 transition-all duration-200">
          <CardHeader className="pb-2">
            <div className="flex justify-between">
              <div>
                <span 
                  onClick={() => filterPostsByTag(post.tag)}
                  className={`inline-block px-2 py-1 text-xs rounded-md ${tagColors[post.tag]} bg-opacity-20 mb-2 cursor-pointer hover:bg-opacity-40`}
                >
                  {post.tag}
                </span>
                <CardTitle className="text-md font-medium">{post.title}</CardTitle>
                {post.course && (
                  <CardDescription 
                    onClick={() => filterPostsByCourse(post.course || null)}
                    className="text-dark-text-secondary text-xs cursor-pointer hover:underline"
                  >
                    {post.course}
                  </CardDescription>
                )}
              </div>
              <span className={`text-xs px-2 py-1 rounded-md ${isPostRead(post.id) ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300'}`}>
                {isPostRead(post.id) ? 'Read' : 'New'}
              </span>
            </div>
          </CardHeader>
          <CardContent className="relative pb-8">
            <CollapsibleContent>
              <p className="text-white/90 text-sm mb-3">{post.content}</p>
            </CollapsibleContent>
            
            <div className="flex justify-between items-end pt-2">
              <div>
                {!isPostExpanded(post.id) && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-xs text-blue-400 hover:text-blue-300 p-0"
                    onClick={() => togglePostExpansion(post.id)}
                  >
                    Read More
                  </Button>
                )}
                
                {isCRMode && (
                  <div className="flex space-x-2 mt-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-7 w-7 p-0" 
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingPost(post);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-7 w-7 p-0 text-red-400 hover:text-red-300" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeletePost(post.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="text-xs text-dark-text-secondary flex flex-col items-end">
                <span>{post.poster}</span>
                <span>{new Date(post.created_at).toLocaleString('en-US', {
                  year: 'numeric',
                  month: '2-digit',
                  day: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true
                })}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </Collapsible>
    );
  };

  const PostForm: React.FC<{ post?: Post; onSubmit: (data: any) => void; onCancel: () => void }> = ({ 
    post, 
    onSubmit, 
    onCancel 
  }) => {
    const form = useForm({
      defaultValues: post ? {
        title: post.title,
        content: post.content,
        tag: post.tag,
        course: post.course || '',
      } : {
        title: '',
        content: '',
        tag: 'Assignment' as PostTag,
        course: '',
      }
    });

    const handleFormSubmit = form.handleSubmit((data) => {
      onSubmit(data);
    });

    return (
      <Card className="bg-dark-surface border-dark-border w-full mb-4">
        <CardHeader>
          <CardTitle>{post ? 'Edit Announcement' : 'New Announcement'}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <label htmlFor="title" className="text-sm font-medium">Title</label>
                <Input
                  id="title"
                  placeholder="Enter announcement title"
                  {...form.register('title', { required: true })}
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="content" className="text-sm font-medium">Description</label>
                <Textarea
                  id="content"
                  placeholder="Enter announcement description"
                  className="min-h-[100px]"
                  {...form.register('content', { required: true })}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="tag" className="text-sm font-medium">Tag</label>
                  <Select 
                    defaultValue={form.getValues('tag')}
                    onValueChange={(value) => form.setValue('tag', value as PostTag)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select tag" />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-surface border-dark-border">
                      {Object.keys(tagColors).map((tag) => (
                        <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="course" className="text-sm font-medium">Course</label>
                  <Select 
                    defaultValue={form.getValues('course')}
                    onValueChange={(value) => form.setValue('course', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select course" />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-surface border-dark-border">
                      {courses.map(course => (
                        <SelectItem key={course.id} value={`${course.code}: ${course.name}`}>
                          {course.code}: {course.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-2">
                <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
                <Button type="submit">{post ? 'Update' : 'Post'}</Button>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    );
  };

  const DeadlineForm: React.FC<{ deadline?: Deadline; onSubmit: (data: any) => void; onCancel: () => void; courses: Course[] }> = ({ 
    deadline, 
    onSubmit, 
    onCancel,
    courses
  }) => {
    const form = useForm({
      defaultValues: deadline ? {
        title: deadline.title,
        course: deadline.course,
        dueDate: deadline.due_date,
        dueTime: deadline.due_time || '00:00',
        tag: deadline.tag,
        completed: deadline.completed || false,
      } : {
        title: '',
        course: '',
        dueDate: new Date().toISOString().split('T')[0],
        dueTime: '00:00',
        tag: 'Assignment' as PostTag,
        completed: false,
      }
    });

    const handleFormSubmit = form.handleSubmit((data) => {
      onSubmit(data);
    });

    return (
      <Card className="bg-dark-surface border-dark-border w-full mb-4">
        <CardHeader>
          <CardTitle>{deadline ? 'Edit Deadline' : 'New Deadline'}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <label htmlFor="title" className="text-sm font-medium">Title</label>
                <Input
                  id="title"
                  placeholder="Enter deadline title"
                  {...form.register('title', { required: true })}
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="course" className="text-sm font-medium">Course</label>
                <Select 
                  defaultValue={form.getValues('course')}
                  onValueChange={(value) => form.setValue('course', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent className="bg-dark-surface border-dark-border">
                    {courses.map(course => (
                      <SelectItem key={course.id} value={`${course.code}: ${course.name}`}>
                        {course.code}: {course.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2 space-y-2">
                  <label htmlFor="dueDate" className="text-sm font-medium">Due Date</label>
                  <Input
                    id="dueDate"
                    type="date"
                    {...form.register('dueDate', { required: true })}
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="dueTime" className="text-sm font-medium">Time</label>
                  <Input
                    id="dueTime"
                    type="time"
                    {...form.register('dueTime', { required: true })}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="tag" className="text-sm font-medium">Tag</label>
                <Select 
                  defaultValue={form.getValues('tag')}
                  onValueChange={(value) => form.setValue('tag', value as PostTag)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select tag" />
                  </SelectTrigger>
                  <SelectContent className="bg-dark-surface border-dark-border">
                    {['Assignment', 'Quiz', 'Exams', 'Others'].map((tag) => (
                      <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <input 
                  type="checkbox" 
                  id="completed" 
                  className="rounded border-input h-4 w-4"
                  checked={form.getValues('completed')}
                  onChange={(e) => form.setValue('completed', e.target.checked)}
                />
                <label htmlFor="completed" className="text-sm font-medium">Mark as completed</label>
              </div>
              
              <div className="flex justify-end space-x-2 pt-2">
                <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
                <Button type="submit">{deadline ? 'Update' : 'Add'}</Button>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6 text-dark-text-secondary">
          <Button 
            onClick={toggleMode} 
            variant="outline" 
            size="sm" 
            className="flex items-center space-x-2"
          >
            {isCRMode ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
            <span className="text-sm">{isCRMode ? 'CR Mode' : 'User View'}</span>
          </Button>
          
          {isCRMode && (
            <div className="flex space-x-2">
              <Button
                onClick={() => setIsAddingPost(true)}
                variant="outline"
                size="sm"
                className="flex items-center"
              >
                <Plus className="h-4 w-4 mr-1" />
                <span>Add Announcement</span>
              </Button>
              
              {(activeTag || activeCourse) && (
                <Button
                  onClick={clearFilters}
                  variant="outline"
                  size="sm"
                >
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </div>

        {!showAllPosts && (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
              <div className="lg:col-span-2 space-y-4">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold">
                    Announcements
                    {activeTag && <span className="ml-2 text-sm">({activeTag})</span>}
                    {activeCourse && <span className="ml-2 text-sm">({activeCourse.split(':')[0]})</span>}
                  </h2>
                </div>
                
                {isAddingPost && (
                  <PostForm
                    onSubmit={handleAddPost}
                    onCancel={() => setIsAddingPost(false)}
                  />
                )}
                
                {editingPost && (
                  <PostForm
                    post={editingPost}
                    onSubmit={handleEditPost}
                    onCancel={() => setEditingPost(null)}
                  />
                )}
                
                <div className="space-y-4">
                  {isLoadingPosts ? (
                    <div className="text-center py-10">Loading announcements...</div>
                  ) : visiblePosts.length > 0 ? (
                    visiblePosts.map(post => (
                      <AnnouncementPost key={post.id} post={post} />
                    ))
                  ) : (
                    <div className="text-center py-10">No announcements found.</div>
                  )}
                </div>
                
                {filteredPosts.length > 3 && (
                  <div className="flex justify-center mt-6">
                    <Button 
                      onClick={() => setShowAllPosts(true)}
                      variant="secondary" 
                      size="sm"
                    >
                      View All
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-dark-surface p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex space-x-2">
                      <Button 
                        variant={!showCompletedDeadlines ? "secondary" : "outline"}
                        size="sm"
                        onClick={() => setShowCompletedDeadlines(false)}
                      >
                        Upcoming
                      </Button>
                      <Button 
                        variant={showCompletedDeadlines ? "secondary" : "outline"}
                        size="sm"
                        onClick={() => setShowCompletedDeadlines(true)}
                      >
                        Completed
                      </Button>
                    </div>
                    
                    {isCRMode && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setIsAddingDeadline(true)}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        <span className="text-xs">Add</span>
                      </Button>
                    )}
                  </div>
                  
                  <h3 className="text-lg font-medium mb-4">
                    {showCompletedDeadlines ? "Completed Deadlines" : "Upcoming Deadlines"}
                  </h3>
                  
                  {isAddingDeadline && (
                    <DeadlineForm
                      courses={courses}
                      onSubmit={handleAddDeadline}
                      onCancel={() => setIsAddingDeadline(false)}
                    />
                  )}
                  
                  {editingDeadline && (
                    <DeadlineForm
                      courses={courses}
                      deadline={editingDeadline}
                      onSubmit={handleEditDeadline}
                      onCancel={() => setEditingDeadline(null)}
                    />
                  )}
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Deadline</TableHead>
                        <TableHead>Due Date</TableHead>
                        {isCRMode && <TableHead></TableHead>}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoadingDeadlines ? (
                        <TableRow>
                          <TableCell colSpan={isCRMode ? 3 : 2} className="text-center py-4">
                            Loading deadlines...
                          </TableCell>
                        </TableRow>
                      ) : displayedDeadlines.length > 0 ? (
                        displayedDeadlines.map(deadline => (
                          <TableRow key={deadline.id}>
                            <TableCell>
                              <div>
                                <span className="font-medium">{deadline.title}</span>
                                <div className="text-xs text-dark-text-secondary">{deadline.course}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1 text-dark-text-secondary" />
                                <span className="text-sm">
                                  {deadline.due_date}
                                  <span className="text-dark-text-secondary ml-2">
                                    {deadline.due_time}
                                  </span>
                                </span>
                              </div>
                            </TableCell>
                            {isCRMode && (
                              <TableCell>
                                <div className="flex space-x-1 justify-end">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-7 w-7 p-0" 
                                    onClick={() => toggleDeadlineCompletion(deadline.id, deadline.completed || false)}
                                  >
                                    <span className={`h-4 w-4 rounded-full border ${deadline.completed ? 'bg-green-500' : 'bg-transparent'}`}></span>
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-7 w-7 p-0" 
                                    onClick={() => setEditingDeadline(deadline)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-7 w-7 p-0 text-red-400 hover:text-red-300" 
                                    onClick={() => handleDeleteDeadline(deadline.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={isCRMode ? 3 : 2} className="text-center py-4 text-dark-text-secondary">
                            No {showCompletedDeadlines ? "completed" : "upcoming"} deadlines
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
            
            <section className="mb-12">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Course Repository</h2>
              </div>
              
              {isCRMode && (
                <CourseManagement courses={courses} isCRMode={isCRMode} />
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {isLoadingCourses ? (
                  <div className="col-span-5 text-center py-10">Loading courses...</div>
                ) : courses.length > 0 ? (
                  courses.map(course => (
                    <div 
                      key={course.id} 
                      onClick={() => setSelectedCourse(course)}
                      className="bg-dark-surface p-4 rounded-lg border border-dark-border hover:border-white/30 cursor-pointer transition-all duration-200"
                    >
                      <div className="flex items-center mb-3">
                        <FolderClosed className="h-5 w-5 mr-2" />
                        <h3 className="text-md font-medium truncate">{course.code}</h3>
                      </div>
                      <p className="text-sm text-dark-text-secondary truncate">
                        {course.name}
                      </p>
                    </div>
                  ))
                ) : (
                  <div className="col-span-5 text-center py-10 text-dark-text-secondary">
                    No courses available. {isCRMode && "Use the 'Add Course' button to create a new course."}
                  </div>
                )}
              </div>
            </section>
          </>
        )}

        {showAllPosts && (
          <section>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">
                All Announcements
                {activeTag && <span className="ml-2 text-sm">({activeTag})</span>}
                {activeCourse && <span className="ml-2 text-sm">({activeCourse.split(':')[0]})</span>}
              </h2>
              <Button 
                onClick={() => setShowAllPosts(false)}
                variant="outline" 
                size="sm"
              >
                Back
              </Button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                {isAddingPost && (
                  <PostForm
                    onSubmit={handleAddPost}
                    onCancel={() => setIsAddingPost(false)}
                  />
                )}
                
                {editingPost && (
                  <PostForm
                    post={editingPost}
                    onSubmit={handleEditPost}
                    onCancel={() => setEditingPost(null)}
                  />
                )}
                
                <div className="space-y-4">
                  {isLoadingPosts ? (
                    <div className="text-center py-10">Loading announcements...</div>
                  ) : filteredPosts.length > 0 ? (
                    filteredPosts.map(post => (
                      <AnnouncementPost key={post.id} post={post} />
                    ))
                  ) : (
                    <div className="p-8 text-center bg-dark-surface rounded-lg">
                      <p className="text-dark-text-secondary">No announcements match the current filters.</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="bg-dark-surface p-4 rounded-lg h-fit">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">Filters</h3>
                  <Filter className="h-4 w-4 text-dark-text-secondary" />
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm text-dark-text-secondary mb-2">By Tag</h4>
                  <div className="flex flex-wrap gap-2">
                    {Object.keys(tagColors).map((tag) => (
                      <span 
                        key={tag}
                        className={`px-2 py-1 text-xs rounded-md ${tagColors[tag as PostTag]} bg-opacity-20 cursor-pointer hover:bg-opacity-30 ${activeTag === tag ? 'ring-2 ring-offset-2 ring-offset-dark-surface' : ''}`}
                        onClick={() => filterPostsByTag(activeTag === tag ? null : tag as PostTag)}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm text-dark-text-secondary mb-2">By Course</h4>
                  <ul className="space-y-1">
                    {courses.map(course => (
                      <li 
                        key={course.id} 
                        className={`text-sm hover:text-white/80 cursor-pointer p-1 rounded ${activeCourse === `${course.code}: ${course.name}` ? 'bg-dark-bg' : ''}`}
                        onClick={() => filterPostsByCourse(activeCourse === `${course.code}: ${course.name}` ? null : `${course.code}: ${course.name}`)}
                      >
                        {course.code}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {(activeTag || activeCourse) && (
                  <div className="mt-4 pt-4 border-t border-dark-border">
                    <Button 
                      onClick={clearFilters}
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                    >
                      Clear Filters
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}
      </main>
      
      {selectedCourse && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-dark-surface rounded-lg p-6 w-full max-w-5xl max-h-[80vh] overflow-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">{selectedCourse.code}: {selectedCourse.name}</h2>
              <Button variant="ghost" size="icon" onClick={() => setSelectedCourse(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <CourseInstructorInfo courseId={selectedCourse.id} isCRMode={isCRMode} />
              <CourseTAInfo courseId={selectedCourse.id} isCRMode={isCRMode} />
            </div>
            
            <h3 className="text-lg font-semibold mb-4">Files</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {isLoadingFolders ? (
                <div className="col-span-2 text-center py-10">Loading folders...</div>
              ) : selectedCourse.folders && selectedCourse.folders.length > 0 ? (
                selectedCourse.folders.map((folder) => (
                  <div key={folder.id} className="bg-dark-bg p-4 rounded-lg border border-dark-border hover:border-white/30 group">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <FolderClosed className="h-5 w-5 mr-2 text-dark-text-secondary" />
                        <span>{folder.name}</span>
                      </div>
                      
                      {isCRMode && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingFolder({
                              courseId: selectedCourse.id,
                              folderId: folder.id,
                              name: folder.name
                            });
                          }}
                        >
                          <PenLine className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    
                    <CourseFileList 
                      courseId={selectedCourse.id}
                      folderId={folder.id}
                      isCRMode={isCRMode}
                    />
                    
                    {isCRMode && (
                      <CourseFileUpload
                        courseId={selectedCourse.id}
                        folderId={folder.id}
                        onFileUploaded={() => {
                          // Refetch files after upload
                          queryClient.invalidateQueries({ queryKey: ['course-files', folder.id] });
                        }}
                      />
                    )}
                  </div>
                ))
              ) : (
                <div className="col-span-2 text-center py-6 text-dark-text-secondary">
                  No folders found for this course
                </div>
              )}
              
              {isCRMode && (
                <Button
                  onClick={() => setAddingFolderToCourse(selectedCourse.id)}
                  className="bg-dark-bg/50 border border-dashed border-dark-border h-full min-h-[60px] flex items-center justify-center text-dark-text-secondary hover:text-white hover:border-white/30"
                >
                  <FolderPlus className="h-5 w-5 mr-2" />
                  <span className="text-sm">Add Folder</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
      
      {editingFolder && (
        <Dialog open={!!editingFolder} onOpenChange={() => setEditingFolder(null)}>
          <DialogContent className="bg-dark-surface border-dark-border">
            <DialogHeader>
              <DialogTitle>Rename Folder</DialogTitle>
              <DialogDescription>
                Enter a new name for this folder.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Input 
                value={editingFolder.name} 
                onChange={(e) => setEditingFolder({...editingFolder, name: e.target.value})}
                className="w-full"
                placeholder="Folder name"
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingFolder(null)}>
                Cancel
              </Button>
              <Button onClick={handleRenameFolder}>
                Save
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {addingFolderToCourse && (
        <Dialog open={!!addingFolderToCourse} onOpenChange={() => setAddingFolderToCourse(null)}>
          <DialogContent className="bg-dark-surface border-dark-border">
            <DialogHeader>
              <DialogTitle>Add New Folder</DialogTitle>
              <DialogDescription>
                Enter a name for the new folder.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Input 
                value={newFolderName} 
                onChange={(e) => setNewFolderName(e.target.value)}
                className="w-full"
                placeholder="Folder name"
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddingFolderToCourse(null)}>
                Cancel
              </Button>
              <Button onClick={handleAddFolder}>
                Add
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default CommunityPage;
