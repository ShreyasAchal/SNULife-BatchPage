
import React from 'react';
import Navbar from '../components/Navbar';
import FeatureBox from '../components/FeatureBox';

const Index = () => {
  const features = [
    {
      title: 'Request & Issue Tracker',
      description: 'Track and manage academic concerns efficiently with our streamlined system.',
      gradientClass: 'purple-gradient',
      number: '/01',
      href: '/issues',
    },
    {
      title: 'Batch Community',
      description: 'Connect with classmates, share resources, and stay updated with announcements.',
      gradientClass: 'orange-red-gradient',
      number: '/02',
      href: '/community',
    },
    {
      title: 'Timetable & Schedule',
      description: 'Manage your academic calendar and never miss important classes or deadlines.',
      gradientClass: 'dark-gray-gradient',
      number: '/03',
      href: '/timetable',
    },
    {
      title: 'Academic Policies Hub',
      description: 'Access official academic regulations, guidelines, and procedures in one place.',
      gradientClass: 'red-gradient',
      number: '/04',
      href: '/policies',
    },
  ];

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16 animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Welcome to <span className="text-white">CSE 2027</span>
          </h1>
          <p className="text-xl text-dark-text-secondary">
            Why should you explore our academic services?
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <FeatureBox
              key={index}
              title={feature.title}
              description={feature.description}
              gradientClass={feature.gradientClass}
              number={feature.number}
              href={feature.href}
            />
          ))}
        </div>
      </main>
    </div>
  );
};

export default Index;
