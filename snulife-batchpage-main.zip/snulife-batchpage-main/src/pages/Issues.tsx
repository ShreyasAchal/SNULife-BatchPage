import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Eye, Filter, Search, Clock, X } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { CreateTicketDialog } from '../components/issues/CreateTicketDialog';
import { IssueTicketItem } from '../components/issues/IssueTicketItem';
import { IssuePagination } from '../components/issues/IssuePagination';
import { CloseTicketDialog } from '../components/issues/CloseTicketDialog';
import { HowToUseDialog } from '../components/issues/HowToUseDialog';
import { CRAnalyticsDialog } from '../components/issues/CRAnalyticsDialog';
import { supabase } from "@/integrations/supabase/client";
import { useToast } from '@/hooks/use-toast';
import { IssueTicket } from '@/types/issue';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';

const sampleOngoingTicket: IssueTicket = {
  id: "sample-ongoing-1",
  ticket_number: "TICK-1234",
  title: "Assignment 2 Clarification",
  description: "I'm having trouble understanding question 3 in Assignment 2. Could you provide more details about what's expected?",
  category: "Academic",
  course: "CSD204: Operating Systems",
  status: "Acknowledged",
  student_name: "Sample Student",
  created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
  closed_at: null,
  cr_remarks: null,
  is_read: true,
  requested_response_time: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // tomorrow
};

const sampleCompletedTicket: IssueTicket = {
  id: "sample-completed-1",
  ticket_number: "TICK-5678",
  title: "Attendance Marking Issue",
  description: "I was present for the lecture on May 2nd but my attendance is marked as absent. Could you please correct this?",
  category: "Attendance",
  course: "CSD210: Introduction to Probability and Statistics",
  status: "Closed",
  student_name: "Sample Student",
  created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), // 10 days ago
  closed_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
  cr_remarks: "Attendance has been updated in the system. Thank you for bringing this to our attention.",
  is_read: true,
  requested_response_time: null
};

const IssuesPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ongoing' | 'completed'>('ongoing');
  const [isCrMode, setIsCrMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [ongoingTickets, setOngoingTickets] = useState<IssueTicket[]>([]);
  const [completedTickets, setCompletedTickets] = useState<IssueTicket[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [selectedTimeFilter, setSelectedTimeFilter] = useState<'today' | '7days' | '30days' | null>(null);
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  const itemsPerPage = 10;
  
  const categories = [...new Set([
    "Academic", "Attendance", "Query", "Clarification", "Request", "Technical", "Others"
  ])];
  
  const courses = [...new Set([
    "Database Systems", "Computer Organization", "Data Structures", 
    "Operating Systems", "Computer Networks Lab", "Machine Learning",
    "Algorithms", "Other"
  ])];

  const fetchTickets = async () => {
    setIsLoading(true);
    try {
      const { data: ongoingData, error: ongoingError } = await supabase
        .from('issues')
        .select('*')
        .neq('status', 'Closed')
        .order('created_at', { ascending: false });
      
      if (ongoingError) throw ongoingError;
      
      const { data: completedData, error: completedError } = await supabase
        .from('issues')
        .select('*')
        .eq('status', 'Closed')
        .order('closed_at', { ascending: false });
      
      if (completedError) throw completedError;
      
      console.log("Ongoing tickets fetched:", ongoingData);
      console.log("Completed tickets fetched:", completedData);
      
      const ongoingResult = ongoingData ? ongoingData as IssueTicket[] : [];
      const completedResult = completedData ? completedData as IssueTicket[] : [];

      if (ongoingResult.length === 0) {
        setOngoingTickets([sampleOngoingTicket]);
      } else {
        setOngoingTickets(ongoingResult);
      }

      if (completedResult.length === 0) {
        setCompletedTickets([sampleCompletedTicket]);
      } else {
        setCompletedTickets(completedResult);
      }
    } catch (error) {
      console.error("Error fetching tickets:", error);
      toast({
        title: "Error",
        description: "Failed to load tickets",
        variant: "destructive"
      });
      setOngoingTickets([sampleOngoingTicket]);
      setCompletedTickets([sampleCompletedTicket]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    if (id.startsWith('sample-')) {
      toast({
        title: "Demo Mode",
        description: `This is a sample ticket. In a real environment, the status would change to ${newStatus}.`
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('issues')
        .update({ status: newStatus })
        .eq('id', id);
        
      if (error) throw error;
      
      toast({
        title: "Status updated",
        description: `Ticket status changed to ${newStatus}`
      });

      fetchTickets();
    } catch (error) {
      console.error("Error updating ticket status:", error);
      toast({
        title: "Error",
        description: "Failed to update ticket status",
        variant: "destructive"
      });
    }
  };

  const handleCloseTicket = (id: string) => {
    if (id.startsWith('sample-')) {
      toast({
        title: "Demo Mode",
        description: "This is a sample ticket. In a real environment, you would be able to close this ticket."
      });
      return;
    }
    
    setSelectedTicketId(id);
    setShowCloseDialog(true);
  };

  const handleTicketClosed = () => {
    setShowCloseDialog(false);
    setSelectedTicketId(null);
    fetchTickets();
    
    if (activeTab === 'ongoing') {
      toast({
        title: "Ticket Closed",
        description: "The ticket has been closed and moved to Completed Requests"
      });
    }
  };

  const filterTickets = (tickets: IssueTicket[]) => {
    return tickets.filter(ticket => {
      const matchesSearch = 
        searchTerm === '' || 
        ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.ticket_number.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = 
        selectedCategory === null || 
        ticket.category === selectedCategory;
      
      const matchesCourse = 
        selectedCourse === null || 
        ticket.course === selectedCourse;
      
      let matchesTime = true;
      if (selectedTimeFilter) {
        const ticketDate = new Date(ticket.created_at);
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const daysDiff = Math.floor((now.getTime() - ticketDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (selectedTimeFilter === 'today') {
          matchesTime = ticketDate >= today;
        } else if (selectedTimeFilter === '7days') {
          matchesTime = daysDiff <= 7;
        } else if (selectedTimeFilter === '30days') {
          matchesTime = daysDiff <= 30;
        }
      }
      
      return matchesSearch && matchesCategory && matchesCourse && matchesTime;
    });
  };

  const handleSortChange = (value: string) => {
    if (value === 'newest') {
      setOngoingTickets([...ongoingTickets].sort(
        (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      ));
      setCompletedTickets([...completedTickets].sort(
        (a, b) => new Date(b.closed_at || b.created_at).getTime() - new Date(a.closed_at || a.created_at).getTime()
      ));
    } else {
      setOngoingTickets([...ongoingTickets].sort(
        (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      ));
      setCompletedTickets([...completedTickets].sort(
        (a, b) => new Date(a.closed_at || a.created_at).getTime() - new Date(b.closed_at || b.created_at).getTime()
      ));
    }
  };

  const renderFilters = () => (
    <Card className="bg-dark-surface border-dark-border mb-6">
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center flex-grow max-w-md">
            <Search className="absolute ml-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search issues..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Select onValueChange={handleSortChange} defaultValue="newest">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest on Top</SelectItem>
              <SelectItem value="oldest">Oldest on Top</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex flex-wrap items-center gap-2">
            <Select value={selectedCategory || "all_categories"} onValueChange={(value) => setSelectedCategory(value === "all_categories" ? null : value)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_categories">All Categories</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedCourse || "all_courses"} onValueChange={(value) => setSelectedCourse(value === "all_courses" ? null : value)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Course" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_courses">All Courses</SelectItem>
                {courses.map(course => (
                  <SelectItem key={course} value={course}>{course}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select 
              value={selectedTimeFilter || "all_time"} 
              onValueChange={(value) => setSelectedTimeFilter(value === "all_time" ? null : value as 'today' | '7days' | '30days' | null)}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Time Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_time">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {(selectedCategory || selectedCourse || selectedTimeFilter) && (
          <div className="flex items-center gap-2 mt-4">
            <span className="text-sm">Active Filters:</span>
            {selectedCategory && (
              <Badge 
                className="flex items-center gap-1 px-2 py-1"
                variant="outline"
              >
                {selectedCategory}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedCategory(null)} 
                />
              </Badge>
            )}
            {selectedCourse && (
              <Badge 
                className="flex items-center gap-1 px-2 py-1"
                variant="outline"
              >
                {selectedCourse}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedCourse(null)} 
                />
              </Badge>
            )}
            {selectedTimeFilter && (
              <Badge 
                className="flex items-center gap-1 px-2 py-1"
                variant="outline"
              >
                {selectedTimeFilter === 'today' ? 'Today' : 
                 selectedTimeFilter === '7days' ? 'Last 7 days' : 'Last 30 days'}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedTimeFilter(null)} 
                />
              </Badge>
            )}
            <Button 
              variant="ghost" 
              size="sm"
              onClick={clearFilters}
              className="ml-2"
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );

  useEffect(() => {
    fetchTickets();
    
    const channel = supabase
      .channel('public:issues')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'issues' }, 
        (payload) => {
          console.log('Real-time update received:', payload);
          fetchTickets();
        }
      )
      .subscribe();
      
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('cr_mode', isCrMode ? 'true' : 'false');
  }, [isCrMode]);

  useEffect(() => {
    const storedMode = localStorage.getItem('cr_mode');
    if (storedMode === 'true') {
      setIsCrMode(true);
    }
  }, []);

  const activeTickets = activeTab === 'ongoing' ? ongoingTickets : completedTickets;
  const filteredTickets = filterTickets(activeTickets);
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const currentTickets = filteredTickets.slice(
    (currentPage - 1) * itemsPerPage, 
    currentPage * itemsPerPage
  );

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedCategory, selectedCourse, selectedTimeFilter, activeTab]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory(null);
    setSelectedCourse(null);
    setSelectedTimeFilter(null);
  };

  const handleTicketCreated = () => {
    fetchTickets();
    setActiveTab('ongoing');
    toast({
      title: "Request Submitted",
      description: "Your request has been submitted successfully and will be reviewed by a CR."
    });
  };

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center text-dark-text-secondary">
            <Eye className="h-5 w-5 mr-2" />
            <span className="text-sm">
              {isCrMode ? 'CR View' : 'Student View'}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsCrMode(!isCrMode)}
            >
              Switch to {isCrMode ? 'Student' : 'CR'} Mode
            </Button>
            <HowToUseDialog />
          </div>
        </div>
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Request & Issue Tracker</h1>
          <p className="text-dark-text-secondary">
            Track and manage your academic concerns efficiently.
          </p>
        </div>

        {(isCrMode || activeTab === 'completed') && renderFilters()}
        
        <div className="mb-6">
          <div className="flex justify-between items-center">
            <div className="flex space-x-4">
              <Button 
                variant={activeTab === 'ongoing' ? "secondary" : "outline"}
                onClick={() => setActiveTab('ongoing')}
              >
                Ongoing Requests
              </Button>
              <Button 
                variant={activeTab === 'completed' ? "secondary" : "outline"}
                onClick={() => setActiveTab('completed')}
              >
                Completed Requests
              </Button>
              
              {isCrMode && <CRAnalyticsDialog />}
            </div>
            
            <CreateTicketDialog onTicketCreated={handleTicketCreated} />
          </div>
        </div>
        
        <div className="border border-dark-border rounded-md overflow-hidden w-full">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ticket #</TableHead>
                <TableHead>Creation Time</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Response Time</TableHead>
                {isCrMode && activeTab === 'ongoing' && <TableHead>Actions</TableHead>}
                {!isCrMode && <TableHead></TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={isCrMode ? 9 : 8} className="text-center py-8">
                    <div className="flex justify-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
                    </div>
                  </TableCell>
                </TableRow>
              ) : currentTickets.length > 0 ? (
                currentTickets.map((ticket) => (
                  <IssueTicketItem 
                    key={ticket.id}
                    ticket={ticket}
                    isCrMode={isCrMode}
                    onStatusChange={isCrMode ? handleStatusChange : undefined}
                    onCloseTicket={isCrMode && ticket.status !== 'Closed' ? handleCloseTicket : undefined}
                  />
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={isCrMode ? 9 : 8} className="text-center py-8 text-dark-text-secondary">
                    No {activeTab} tickets found matching your criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        
        <div className="mt-4">
          <IssuePagination 
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </div>
      </main>
      
      <CloseTicketDialog 
        isOpen={showCloseDialog}
        onClose={() => setShowCloseDialog(false)}
        ticketId={selectedTicketId}
        onSuccess={handleTicketClosed}
      />
    </div>
  );
};

export default IssuesPage;
