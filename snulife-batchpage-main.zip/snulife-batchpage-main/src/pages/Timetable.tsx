import React, { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Edit2, Clock } from "lucide-react";
import { format, addMonths, subMonths, addWeeks, subWeeks } from "date-fns";
import Navbar from "@/components/Navbar";
import CustomCalendar from "@/components/ui/custom-calendar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

const HOLIDAYS = [
  { date: new Date(2025, 0, 1), name: "New Year's Day", type: "university" },
  { date: new Date(2025, 0, 26), name: "Republic Day", type: "university" },
  { date: new Date(2025, 2, 14), name: "Holi", type: "university" },
  { date: new Date(2025, 7, 15), name: "Independence Day", type: "university" },
  { date: new Date(2025, 9, 2), name: "Gandhi Jayanti", type: "university" },
  { date: new Date(2025, 10, 4), name: "Diwali", type: "university" },
  { date: new Date(2025, 0, 15), name: "Makar Sankranti", type: "restricted" },
  { date: new Date(2025, 7, 29), name: "Raksha Bandhan", type: "restricted" },
  { date: new Date(2025, 8, 7), name: "Janmashtami", type: "restricted" },
];

const DEADLINES = [
  { date: new Date(2025, 1, 15), name: "Assignment 1", course: "CSD317" },
  { date: new Date(2025, 2, 10), name: "Assignment 2", course: "CSD204" },
  { date: new Date(2025, 3, 5), name: "Project Submission", course: "CSD212" },
];

const EXAMS = [
  { date: new Date(2025, 3, 25), name: "Last Date for Classes" },
  { date: new Date(2025, 3, 30), name: "DES211 Exam" },
  { date: new Date(2025, 3, 30), name: "CSD317 Exam" },
  { date: new Date(2025, 4, 5), name: "CSD212 Exam" },
  { date: new Date(2025, 4, 7), name: "CSD204 Exam" },
  { date: new Date(2025, 4, 9), name: "CSD210 Exam" },
];

const GROUPS = [
  { code: "CSD21", name: "CSD21" },
  { code: "CSD22", name: "CSD22" },
  { code: "CSD23", name: "CSD23" },
  { code: "CSD24", name: "CSD24" },
];

const COURSES_REPOSITORY = [
  { code: "CSD21", name: "Algorithms" },
  { code: "CSD22", name: "Data Structures" },
  { code: "CSD23", name: "Operating Systems" },
  { code: "CSD24", name: "Databases" },
];

const eventFormSchema = z.object({
  category: z.enum(["holiday", "exam"]),
  name: z.string().min(1, "Name is required"),
  date: z.date({
    required_error: "Date is required",
  }),
  type: z.enum(["university", "restricted"]).optional(),
  link: z.string().optional(),
});

const courseFormSchema = z.object({
  repeats: z.boolean().default(true),
  course: z.string().min(1, "Course is required"),
  component: z.enum(["Lecture", "Tutorial", "Practical"]),
  componentDisplay: z.enum(["L", "P1", "P2", "T1", "T2"]),
  day: z.enum(["0", "1", "2", "3", "4", "5", "6"]).optional(),
  startDate: z.date().optional(),
  endDate: z.date().optional(),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  academicGroups: z.array(z.string()).min(1, "Select at least one group"),
  date: z.date().optional(),
  venue: z.string().optional(),
});

type Event = {
  date: Date;
  name: string;
  type?: string;
  course?: string;
  category: "holiday" | "deadline" | "exam" | "course";
  link?: string;
  component?: string;
  componentDisplay?: string;
  startTime?: string;
  endTime?: string;
  academicGroups?: string[];
  repeats?: boolean;
  day?: number;
  startDate?: Date;
  endDate?: Date;
  dbId?: string;
  venue?: string;
};

const TimetablePage = () => {
  const [date, setDate] = useState<Date>(new Date());
  const [view, setView] = useState<"month" | "week">("month");
  const [filters, setFilters] = useState<{
    holidays: boolean;
    deadlines: boolean;
    exams: boolean;
    courses: boolean;
  }>({
    holidays: false,
    deadlines: false,
    exams: false,
    courses: false,
  });
  const [courseCode, setCourseCode] = useState<string>("all");
  const [customEvents, setCustomEvents] = useState<Event[]>([]);
  const [isEditorMode, setIsEditorMode] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"event" | "course">("event");
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  const eventForm = useForm<z.infer<typeof eventFormSchema>>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      category: "holiday",
      name: "",
      link: "",
    },
  });

  const initialCourseFormValues = {
    repeats: true,
    course: "",
    component: "Lecture" as const,
    componentDisplay: "L" as const,
    startTime: "",
    endTime: "",
    academicGroups: [] as string[],
    venue: "",
    day: undefined,
    startDate: undefined,
    endDate: undefined,
    date: undefined,
  };

  const courseForm = useForm<z.infer<typeof courseFormSchema>>({
    resolver: zodResolver(courseFormSchema),
    defaultValues: initialCourseFormValues,
  });

  useEffect(() => {
    if (view === "month") {
      if (filters.courses) {
        setFilters(prev => ({ ...prev, courses: false }));
      }
    }
  }, [view, filters]);

  const [repoCourses, setRepoCourses] = useState<{ id: string; code: string; name: string }[]>([]);
  const [repeatingCourseEvents, setRepeatingCourseEvents] = useState<any[]>([]);
  const [nonRepeatingCourseEvents, setNonRepeatingCourseEvents] = useState<any[]>([]);
  const [customCalendarEvents, setCustomCalendarEvents] = useState<any[]>([]);
  const [deadlines, setDeadlines] = useState<any[]>([]);
  const [calendarChanged, setCalendarChanged] = useState(0);

  useEffect(() => {
    (async () => {
      const { data: coursesData } = await supabase.from("courses").select("id, code, name");
      setRepoCourses(coursesData ?? []);
      const { data: rep } = await supabase.from("repeating_course_events").select("*");
      setRepeatingCourseEvents(rep ?? []);
      const { data: nonrep } = await supabase.from("non_repeating_course_events").select("*");
      setNonRepeatingCourseEvents(nonrep ?? []);
      const { data: custom } = await supabase.from("custom_calendar_events").select("*");
      setCustomCalendarEvents(custom ?? []);
      const { data: deadlinesData } = await supabase.from("deadlines").select("*, course_id");
      setDeadlines(deadlinesData ?? []);
    })();
  }, [calendarChanged]);

  const onEventSubmit = async (values: z.infer<typeof eventFormSchema>) => {
    const { error } = await supabase.from("custom_calendar_events").insert([
      {
        category: values.category,
        name: values.name,
        event_date: values.date ? values.date.toISOString().split("T")[0] : null,
        type: values.type ?? null,
        link: values.link ?? null,
      },
    ]);
    if (error) {
      toast({ title: "Error", description: "Failed to add event." });
      return;
    }
    toast({ title: "Event added!" });
    eventForm.reset();
    setCalendarChanged((x) => x + 1);
  };

  const onCourseSubmit = async (values: z.infer<typeof courseFormSchema>) => {
    const courseObj = repoCourses.find((c) => c.code === values.course);
    if (!courseObj) {
      toast({ title: "Error", description: "Invalid course selected." });
      return;
    }
    const commonFields = {
      course_id: courseObj.id,
      component: values.component,
      component_display: values.componentDisplay,
      start_time: values.startTime,
      end_time: values.endTime,
      academic_groups: values.academicGroups,
      venue: values.venue ?? "",
    };
    if (values.repeats) {
      if (!values.day || !values.startDate || !values.endDate) {
        toast({
          title: "Error",
          description: "Day, starting date and ending date are required for repeating courses.",
        });
        return;
      }
      const input = {
        ...commonFields,
        day: Number(values.day),
        start_date: values.startDate.toISOString().split("T")[0],
        end_date: values.endDate.toISOString().split("T")[0],
      };
      const { error } = await supabase.from("repeating_course_events").insert([input]);
      if (error) {
        toast({ title: "Error", description: "Failed to add course event." });
        return;
      }
    } else {
      if (!values.date) {
        toast({ title: "Error", description: "Date is required for non-repeating courses." });
        return;
      }
      const input = {
        ...commonFields,
        event_date: values.date.toISOString().split("T")[0],
      };
      const { error } = await supabase.from("non_repeating_course_events").insert([input]);
      if (error) {
        toast({ title: "Error", description: "Failed to add course event." });
        return;
      }
    }
    toast({ title: "Course event added!" });
    courseForm.reset(initialCourseFormValues);
    setCalendarChanged((x) => x + 1);
  };

  const deleteCustomEvent = async (id: string) => {
    await supabase.from("custom_calendar_events").delete().eq("id", id);
    setCalendarChanged((x) => x + 1);
    toast({ title: "Event deleted" });
  };

  const deleteRepeatingEvent = async (id: string) => {
    await supabase.from("repeating_course_events").delete().eq("id", id);
    setCalendarChanged((x) => x + 1);
    toast({ title: "Course event deleted" });
  };

  const deleteNonRepeatingEvent = async (id: string) => {
    await supabase.from("non_repeating_course_events").delete().eq("id", id);
    setCalendarChanged((x) => x + 1);
    toast({ title: "Course event deleted" });
  };

  const courseEvents: Event[] = [
    ...(repeatingCourseEvents ?? []).map((ev) => ({
      date: new Date(ev.start_date),
      name: `${repoCourses.find((c) => c.id === ev.course_id)?.code || ""} ${ev.component_display}`,
      course: repoCourses.find((c) => c.id === ev.course_id)?.code,
      category: "course" as const,
      component: ev.component,
      componentDisplay: ev.component_display,
      startTime: ev.start_time,
      endTime: ev.end_time,
      day: ev.day,
      repeats: true,
      startDate: new Date(ev.start_date),
      endDate: new Date(ev.end_date),
      academicGroups: ev.academic_groups,
      venue: ev.venue,
      dbId: ev.id,
    })),
    ...(nonRepeatingCourseEvents ?? []).map((ev) => ({
      date: new Date(ev.event_date),
      name: `${repoCourses.find((c) => c.id === ev.course_id)?.code || ""} ${ev.component_display}`,
      course: repoCourses.find((c) => c.id === ev.course_id)?.code,
      category: "course" as const,
      component: ev.component,
      componentDisplay: ev.component_display,
      startTime: ev.start_time,
      endTime: ev.end_time,
      day: new Date(ev.event_date).getDay(),
      repeats: false,
      academicGroups: ev.academic_groups,
      venue: ev.venue,
      dbId: ev.id,
    })),
  ];

  const deadlineEvents: Event[] = (deadlines ?? []).map((d) => {
    const courseObj = repoCourses.find((c) => c.id === d.course_id);
    return {
      date: new Date(d.due_date),
      name: d.title,
      course: courseObj ? `${courseObj.code}: ${courseObj.name}` : d.course_id || "",
      category: "deadline" as const,
      startTime: d.due_time?.slice?.(0, 5) || "",
      endTime: "",
      dbId: d.id,
    };
  });

  const customEventsDb: Event[] = (customCalendarEvents ?? []).map((ev) => ({
    date: new Date(ev.event_date),
    name: ev.name,
    category: ev.category as "holiday" | "exam",
    type: ev.type,
    link: ev.link,
    dbId: ev.id,
  }));

  const getCourseFullName = (code: string | undefined) => {
    if (!code) return "";
    const course = repoCourses.find((c) => c.code === code);
    return course ? `${course.code} - ${course.name}` : code;
  };

  const events = useMemo(() => {
    let allEvents: Event[] = [];
    if (filters.courses) allEvents = allEvents.concat(courseEvents);
    if (filters.deadlines) allEvents = allEvents.concat(deadlineEvents);
    if (filters.holidays || filters.exams) {
      if (filters.holidays) {
        allEvents = [
          ...allEvents,
          ...HOLIDAYS.map((ev) => ({
            ...ev,
            category: "holiday" as const,
          })),
        ];
      }
      if (filters.exams) {
        allEvents = [
          ...allEvents,
          ...EXAMS.map((ev) => ({
            ...ev,
            category: "exam" as const,
          })),
        ];
      }
      allEvents = allEvents.concat(customEventsDb);
    }
    if (!filters.holidays && !filters.courses && !filters.deadlines && !filters.exams) {
      allEvents = [];
    }
    return allEvents.filter((event) => {
      if (event.category === "course" && courseCode !== "all") {
        return event.course === courseCode;
      }
      return true;
    });
  }, [filters, courseCode, courseEvents, customEventsDb, deadlineEvents]);

  const handleDateChange = (amount: number) => {
    if (view === "month") {
      amount > 0
        ? setDate(addMonths(date, amount))
        : setDate(subMonths(date, Math.abs(amount)));
    } else {
      amount > 0
        ? setDate(addWeeks(date, amount))
        : setDate(subWeeks(date, Math.abs(amount)));
    }
  };

  const handleFilterChange = (key: keyof typeof filters) => {
    if (key === "courses") {
      if (!filters.courses) {
        setFilters({
          holidays: false,
          deadlines: false,
          exams: false,
          courses: true,
        });
        setView("week");
      } else {
        setFilters(prev => ({ ...prev, [key]: !prev[key] }));
      }
    } else {
      setFilters(prev => ({
        ...prev,
        [key]: !prev[key],
        courses: false,
      }));
    }
  };

  const watchComponent = courseForm.watch("component");
  const watchRepeats = courseForm.watch("repeats");
  const showHolidayTypeField = eventForm.watch("category") === "holiday";

  const handleCalendarEventDelete = async (event: Event) => {
    if (event.category === "course") {
      if (event.repeats) {
        await deleteRepeatingEvent(event.dbId!);
      } else {
        await deleteNonRepeatingEvent(event.dbId!);
      }
    }
    if (event.category === "holiday" || event.category === "exam") {
      await deleteCustomEvent(event.dbId!);
    }
    setSelectedEvent(null);
  };

  return (
    <div className="min-h-screen bg-dark-bg">
      <Navbar />
      
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6">Timetable & Schedule</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <Card className="lg:col-span-3 border-border">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-5 w-5" />
                  <span>
                    {format(date, view === "month" ? "MMMM yyyy" : "'Week of' MMMM d, yyyy")}
                  </span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditorMode(!isEditorMode)}
                  className="flex items-center gap-1"
                >
                  {isEditorMode ? <CalendarIcon className="h-4 w-4" /> : <Edit2 className="h-4 w-4" />}
                  {isEditorMode ? "View Mode" : "Editor Mode"}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CustomCalendar 
                date={date} 
                view={view} 
                events={events} 
                className="h-full"
                repoCourses={repoCourses}
                deadlineEvents={deadlineEvents}
                onEventClick={setSelectedEvent}
                selectedEvent={selectedEvent}
                onEventDelete={handleCalendarEventDelete}
                isEditorMode={isEditorMode}
              />
              
              <div className="flex justify-between mt-6">
                <button
                  onClick={() => handleDateChange(-1)}
                  className="flex items-center gap-1 text-sm"
                >
                  <ChevronLeft className="h-4 w-4" />
                  {view === "month" ? "Previous Month" : "Previous Week"}
                </button>
                <button
                  onClick={() => handleDateChange(1)}
                  className="flex items-center gap-1 text-sm"
                >
                  {view === "month" ? "Next Month" : "Next Week"}
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </CardContent>
          </Card>
          
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium mb-2">View Mode</h3>
                  <ToggleGroup type="single" value={view} onValueChange={(val) => val && setView(val as "month" | "week")}>
                    <ToggleGroupItem value="month">Monthly</ToggleGroupItem>
                    <ToggleGroupItem value="week">Weekly</ToggleGroupItem>
                  </ToggleGroup>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Categories</h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="holidays" 
                        checked={filters.holidays} 
                        disabled={filters.courses}
                        onCheckedChange={() => handleFilterChange("holidays")} 
                      />
                      <Label htmlFor="holidays">Holidays</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="deadlines" 
                        checked={filters.deadlines}
                        disabled={filters.courses} 
                        onCheckedChange={() => handleFilterChange("deadlines")} 
                      />
                      <Label htmlFor="deadlines">Deadlines</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="exams" 
                        checked={filters.exams}
                        disabled={filters.courses} 
                        onCheckedChange={() => handleFilterChange("exams")} 
                      />
                      <Label htmlFor="exams">Exams</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="courses" 
                        checked={filters.courses}
                        disabled={view !== "week"} 
                        onCheckedChange={() => handleFilterChange("courses")} 
                      />
                      <Label htmlFor="courses" className={view !== "week" ? "text-muted-foreground" : ""}>
                        Courses {view !== "week" && "(Weekly View Only)"}
                      </Label>
                    </div>
                  </div>
                </div>
                
                {filters.courses && (
                  <div>
                    <h3 className="text-sm font-medium mb-2">Course Code</h3>
                    <Select value={courseCode} onValueChange={(val) => setCourseCode(val)}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select course code" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover text-popover-foreground">
                        <SelectItem value="CSD21">CSD21</SelectItem>
                        <SelectItem value="CSD22">CSD22</SelectItem>
                        <SelectItem value="CSD23">CSD23</SelectItem>
                        <SelectItem value="CSD24">CSD24</SelectItem>
                        <SelectItem value="all">All Courses</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Legend</h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-red-900/60 rounded"></div>
                      <span>University Holidays</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-yellow-700/60 rounded"></div>
                      <span>Restricted Holidays</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-900/60 rounded"></div>
                      <span>Deadlines</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-purple-900/60 rounded"></div>
                      <span>Exams</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-900/70 rounded"></div>
                      <span>Course Events</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {isEditorMode && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Plus className="h-4 w-4" />
                      <span>Add Event</span>
                    </div>
                    {view === "week" && (
                      <ToggleGroup 
                        type="single" 
                        value={activeTab} 
                        onValueChange={(val) => val && setActiveTab(val as "event" | "course")}
                        className="border border-border rounded-md"
                      >
                        <ToggleGroupItem value="event" className="text-xs h-8">Event</ToggleGroupItem>
                        <ToggleGroupItem value="course" className="text-xs h-8">Course</ToggleGroupItem>
                      </ToggleGroup>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {(activeTab === "event" || view === "month") ? (
                    <Form {...eventForm}>
                      <form onSubmit={eventForm.handleSubmit(onEventSubmit)} className="space-y-4">
                        <FormField
                          control={eventForm.control}
                          name="category"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Category</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select category" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent className="bg-popover text-popover-foreground">
                                  <SelectItem value="holiday">Holiday</SelectItem>
                                  <SelectItem value="exam">Exam</SelectItem>
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />

                        {showHolidayTypeField && (
                          <FormField
                            control={eventForm.control}
                            name="type"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Holiday Type</FormLabel>
                                <Select 
                                  onValueChange={field.onChange} 
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select holiday type" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-popover text-popover-foreground">
                                    <SelectItem value="university">University Holiday</SelectItem>
                                    <SelectItem value="restricted">Restricted Holiday</SelectItem>
                                  </SelectContent>
                                </Select>
                              </FormItem>
                            )}
                          />
                        )}

                        <FormField
                          control={eventForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter event name" {...field} />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date</FormLabel>
                              <FormControl>
                                <Input 
                                  type="date" 
                                  onChange={(e) => field.onChange(e.target.valueAsDate)}
                                  className="bg-background"
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="link"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Resource Link (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="https://..." {...field} />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <Button type="submit" className="w-full">Add Event</Button>
                      </form>
                    </Form>
                  ) : (
                    <Form {...courseForm}>
                      <form onSubmit={courseForm.handleSubmit(onCourseSubmit)} className="space-y-4">
                        <FormField
                          control={courseForm.control}
                          name="repeats"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center gap-2 border p-2 rounded">
                              <FormLabel className="flex-auto">Repeats Weekly</FormLabel>
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={(checked) => field.onChange(!!checked)}
                                  id="repeats"
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={courseForm.control}
                          name="course"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Course</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select course" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {repoCourses.map((c) => (
                                    <SelectItem key={c.code} value={c.code}>{c.code} - {c.name}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={courseForm.control}
                            name="component"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Component</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select component" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Lecture">Lecture</SelectItem>
                                    <SelectItem value="Tutorial">Tutorial</SelectItem>
                                    <SelectItem value="Practical">Practical</SelectItem>
                                  </SelectContent>
                                </Select>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={courseForm.control}
                            name="componentDisplay"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Display As</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Display as" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {watchComponent === "Lecture" && <SelectItem value="L">L</SelectItem>}
                                    {watchComponent === "Tutorial" && (
                                      <>
                                        <SelectItem value="T1">T1</SelectItem>
                                        <SelectItem value="T2">T2</SelectItem>
                                      </>
                                    )}
                                    {watchComponent === "Practical" && (
                                      <>
                                        <SelectItem value="P1">P1</SelectItem>
                                        <SelectItem value="P2">P2</SelectItem>
                                      </>
                                    )}
                                  </SelectContent>
                                </Select>
                              </FormItem>
                            )}
                          />
                        </div>

                        {watchRepeats ? (
                          <>
                            <FormField
                              control={courseForm.control}
                              name="day"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Day</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Day of week" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="0">Sunday</SelectItem>
                                      <SelectItem value="1">Monday</SelectItem>
                                      <SelectItem value="2">Tuesday</SelectItem>
                                      <SelectItem value="3">Wednesday</SelectItem>
                                      <SelectItem value="4">Thursday</SelectItem>
                                      <SelectItem value="5">Friday</SelectItem>
                                      <SelectItem value="6">Saturday</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </FormItem>
                              )}
                            />

                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={courseForm.control}
                                name="startDate"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Start Date</FormLabel>
                                    <FormControl>
                                      <Input 
                                        type="date" 
                                        onChange={(e) => field.onChange(e.target.valueAsDate)}
                                        className="bg-background"
                                      />
                                    </FormControl>
                                  </FormItem>
                                )}
                              />

                              <FormField
                                control={courseForm.control}
                                name="endDate"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>End Date</FormLabel>
                                    <FormControl>
                                      <Input 
                                        type="date" 
                                        onChange={(e) => field.onChange(e.target.valueAsDate)}
                                        className="bg-background"
                                      />
                                    </FormControl>
                                  </FormItem>
                                )}
                              />
                            </div>
                          </>
                        ) : (
                          <FormField
                            control={courseForm.control}
                            name="date"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Date</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="date" 
                                    onChange={(e) => field.onChange(e.target.valueAsDate)}
                                    className="bg-background"
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        )}

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={courseForm.control}
                            name="startTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Start Time</FormLabel>
                                <FormControl>
                                  <Input type="time" {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={courseForm.control}
                            name="endTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>End Time</FormLabel>
                                <FormControl>
                                  <Input type="time" {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={courseForm.control}
                          name="venue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Venue (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter venue" {...field} />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={courseForm.control}
                          name="academicGroups"
                          render={() => (
                            <FormItem>
                              <FormLabel>Academic Groups</FormLabel>
                              <div className="border p-3 rounded grid grid-cols-2 gap-2">
                                {GROUPS.map((group) => (
                                  <div key={group.code} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`group-${group.code}`}
                                      checked={courseForm.watch("academicGroups").includes(group.code)}
                                      onCheckedChange={(checked) => {
                                        const currentGroups = courseForm.getValues("academicGroups");
                                        if (checked) {
                                          courseForm.setValue("academicGroups", [...currentGroups, group.code]);
                                        } else {
                                          courseForm.setValue(
                                            "academicGroups",
                                            currentGroups.filter((g) => g !== group.code)
                                          );
                                        }
                                      }}
                                    />
                                    <Label htmlFor={`group-${group.code}`} className="text-sm">
                                      {group.name}
                                    </Label>
                                  </div>
                                ))}
                              </div>
                            </FormItem>
                          )}
                        />

                        <Button type="submit" className="w-full">Add Course Event</Button>
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimetablePage;
