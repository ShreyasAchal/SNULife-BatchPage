export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      calendar_events: {
        Row: {
          category: string
          course_id: string | null
          created_at: string
          description: string | null
          end_time: string | null
          event_date: string
          id: string
          start_time: string | null
          title: string
          updated_at: string
        }
        Insert: {
          category?: string
          course_id?: string | null
          created_at?: string
          description?: string | null
          end_time?: string | null
          event_date: string
          id?: string
          start_time?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          category?: string
          course_id?: string | null
          created_at?: string
          description?: string | null
          end_time?: string | null
          event_date?: string
          id?: string
          start_time?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "calendar_events_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      course_files: {
        Row: {
          course_id: string
          created_at: string
          file_name: string
          file_type: string
          file_url: string
          folder_id: string
          id: string
          updated_at: string
        }
        Insert: {
          course_id: string
          created_at?: string
          file_name: string
          file_type: string
          file_url: string
          folder_id: string
          id?: string
          updated_at?: string
        }
        Update: {
          course_id?: string
          created_at?: string
          file_name?: string
          file_type?: string
          file_url?: string
          folder_id?: string
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_files_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "course_files_folder_id_fkey"
            columns: ["folder_id"]
            isOneToOne: false
            referencedRelation: "course_folders"
            referencedColumns: ["id"]
          },
        ]
      }
      course_folders: {
        Row: {
          course_id: string
          created_at: string
          id: string
          is_editable: boolean | null
          name: string
        }
        Insert: {
          course_id: string
          created_at?: string
          id?: string
          is_editable?: boolean | null
          name: string
        }
        Update: {
          course_id?: string
          created_at?: string
          id?: string
          is_editable?: boolean | null
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_folders_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      course_instructors: {
        Row: {
          course_id: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          office: string | null
          office_hours: string | null
          rslookup_page: string | null
          snu_page: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          course_id?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          office?: string | null
          office_hours?: string | null
          rslookup_page?: string | null
          snu_page?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          course_id?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          office?: string | null
          office_hours?: string | null
          rslookup_page?: string | null
          snu_page?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "course_instructors_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      course_tas: {
        Row: {
          course_id: string | null
          created_at: string
          department: string | null
          email: string | null
          graduation_year: string | null
          id: string
          name: string
          office: string | null
          phone: string | null
          role: string
          school: string | null
          updated_at: string
        }
        Insert: {
          course_id?: string | null
          created_at?: string
          department?: string | null
          email?: string | null
          graduation_year?: string | null
          id?: string
          name: string
          office?: string | null
          phone?: string | null
          role?: string
          school?: string | null
          updated_at?: string
        }
        Update: {
          course_id?: string | null
          created_at?: string
          department?: string | null
          email?: string | null
          graduation_year?: string | null
          id?: string
          name?: string
          office?: string | null
          phone?: string | null
          role?: string
          school?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_tas_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          code: string
          created_at: string
          id: string
          name: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      cr_analytics: {
        Row: {
          avg_completion_time: string
          avg_response_time: string
          cr_batch: string
          cr_name: string
          created_at: string
          id: string
          satisfied_count: number
          students_with_tickets: number
          tickets_closed: number
          tickets_raised: number
          total_students: number
          unsatisfied_count: number
          updated_at: string
        }
        Insert: {
          avg_completion_time?: string
          avg_response_time?: string
          cr_batch: string
          cr_name: string
          created_at?: string
          id?: string
          satisfied_count?: number
          students_with_tickets?: number
          tickets_closed?: number
          tickets_raised?: number
          total_students?: number
          unsatisfied_count?: number
          updated_at?: string
        }
        Update: {
          avg_completion_time?: string
          avg_response_time?: string
          cr_batch?: string
          cr_name?: string
          created_at?: string
          id?: string
          satisfied_count?: number
          students_with_tickets?: number
          tickets_closed?: number
          tickets_raised?: number
          total_students?: number
          unsatisfied_count?: number
          updated_at?: string
        }
        Relationships: []
      }
      cr_monthly_analytics: {
        Row: {
          avg_closing_time: number
          cr_analytics_id: string
          created_at: string
          id: string
          month: string
          tickets_completed: number
          updated_at: string
        }
        Insert: {
          avg_closing_time?: number
          cr_analytics_id: string
          created_at?: string
          id?: string
          month: string
          tickets_completed?: number
          updated_at?: string
        }
        Update: {
          avg_closing_time?: number
          cr_analytics_id?: string
          created_at?: string
          id?: string
          month?: string
          tickets_completed?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cr_monthly_analytics_cr_analytics_id_fkey"
            columns: ["cr_analytics_id"]
            isOneToOne: false
            referencedRelation: "cr_analytics"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_calendar_events: {
        Row: {
          category: string
          created_at: string
          event_date: string
          id: string
          link: string | null
          name: string
          type: string | null
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          event_date: string
          id?: string
          link?: string | null
          name: string
          type?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          event_date?: string
          id?: string
          link?: string | null
          name?: string
          type?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      deadlines: {
        Row: {
          completed: boolean
          course_id: string | null
          created_at: string
          due_date: string
          due_time: string
          id: string
          tag: string
          title: string
          updated_at: string
        }
        Insert: {
          completed?: boolean
          course_id?: string | null
          created_at?: string
          due_date: string
          due_time?: string
          id?: string
          tag: string
          title: string
          updated_at?: string
        }
        Update: {
          completed?: boolean
          course_id?: string | null
          created_at?: string
          due_date?: string
          due_time?: string
          id?: string
          tag?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "deadlines_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      issues: {
        Row: {
          category: string
          closed_at: string | null
          course: string
          cr_remarks: string | null
          created_at: string
          description: string
          id: string
          image_url: string | null
          is_read: boolean
          requested_response_time: string | null
          status: string
          student_name: string
          ticket_number: string
          title: string
        }
        Insert: {
          category: string
          closed_at?: string | null
          course: string
          cr_remarks?: string | null
          created_at?: string
          description: string
          id?: string
          image_url?: string | null
          is_read?: boolean
          requested_response_time?: string | null
          status?: string
          student_name?: string
          ticket_number?: string
          title: string
        }
        Update: {
          category?: string
          closed_at?: string | null
          course?: string
          cr_remarks?: string | null
          created_at?: string
          description?: string
          id?: string
          image_url?: string | null
          is_read?: boolean
          requested_response_time?: string | null
          status?: string
          student_name?: string
          ticket_number?: string
          title?: string
        }
        Relationships: []
      }
      non_repeating_course_events: {
        Row: {
          academic_groups: string[]
          component: string
          component_display: string
          course_id: string
          created_at: string
          end_time: string
          event_date: string
          id: string
          start_time: string
          updated_at: string
          venue: string | null
        }
        Insert: {
          academic_groups: string[]
          component: string
          component_display: string
          course_id: string
          created_at?: string
          end_time: string
          event_date: string
          id?: string
          start_time: string
          updated_at?: string
          venue?: string | null
        }
        Update: {
          academic_groups?: string[]
          component?: string
          component_display?: string
          course_id?: string
          created_at?: string
          end_time?: string
          event_date?: string
          id?: string
          start_time?: string
          updated_at?: string
          venue?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "non_repeating_course_events_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      post_reads: {
        Row: {
          id: string
          post_id: string
          read_at: string
          user_id: string
        }
        Insert: {
          id?: string
          post_id: string
          read_at?: string
          user_id: string
        }
        Update: {
          id?: string
          post_id?: string
          read_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_reads_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          content: string
          course_id: string | null
          created_at: string
          id: string
          poster: string
          tag: string
          title: string
          updated_at: string
        }
        Insert: {
          content: string
          course_id?: string | null
          created_at?: string
          id?: string
          poster?: string
          tag: string
          title: string
          updated_at?: string
        }
        Update: {
          content?: string
          course_id?: string | null
          created_at?: string
          id?: string
          poster?: string
          tag?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "posts_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      repeating_course_events: {
        Row: {
          academic_groups: string[]
          component: string
          component_display: string
          course_id: string
          created_at: string
          day: number
          end_date: string
          end_time: string
          id: string
          start_date: string
          start_time: string
          updated_at: string
          venue: string | null
        }
        Insert: {
          academic_groups: string[]
          component: string
          component_display: string
          course_id: string
          created_at?: string
          day: number
          end_date: string
          end_time: string
          id?: string
          start_date: string
          start_time: string
          updated_at?: string
          venue?: string | null
        }
        Update: {
          academic_groups?: string[]
          component?: string
          component_display?: string
          course_id?: string
          created_at?: string
          day?: number
          end_date?: string
          end_time?: string
          id?: string
          start_date?: string
          start_time?: string
          updated_at?: string
          venue?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "repeating_course_events_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      close_ticket: {
        Args: { ticket_id: string; remarks: string }
        Returns: undefined
      }
      create_ticket: {
        Args: {
          p_title: string
          p_description: string
          p_category: string
          p_course: string
          p_requested_response_time: string
        }
        Returns: undefined
      }
      get_completed_tickets: {
        Args: Record<PropertyKey, never>
        Returns: Json[]
      }
      get_cr_analytics: {
        Args: Record<PropertyKey, never>
        Returns: {
          id: string
          cr_name: string
          cr_batch: string
          tickets_raised: number
          tickets_closed: number
          total_students: number
          students_with_tickets: number
          avg_response_time: string
          avg_completion_time: string
          satisfied_count: number
          unsatisfied_count: number
          monthly_data: Json
        }[]
      }
      get_ongoing_tickets: {
        Args: Record<PropertyKey, never>
        Returns: Json[]
      }
      update_cr_analytics: {
        Args: {
          p_id: string
          p_cr_name: string
          p_cr_batch: string
          p_tickets_raised: number
          p_tickets_closed: number
          p_total_students: number
          p_students_with_tickets: number
          p_avg_response_time: string
          p_avg_completion_time: string
          p_satisfied_count: number
          p_unsatisfied_count: number
          p_monthly_data: Json
        }
        Returns: undefined
      }
      update_issue_read_status: {
        Args: { issue_id: string; read_status: boolean }
        Returns: undefined
      }
      update_ticket_status: {
        Args: { ticket_id: string; new_status: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
