
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from "@/integrations/supabase/client";
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useToast } from '@/hooks/use-toast';
import { Json } from '@/integrations/supabase/types';

interface CRAnalytics {
  id: string;
  cr_name: string;
  cr_batch: string;
  tickets_raised: number;
  tickets_closed: number;
  total_students: number;
  students_with_tickets: number;
  avg_response_time: string;
  avg_completion_time: string;
  satisfied_count: number;
  unsatisfied_count: number;
  monthly_data: {
    month: string;
    ticketsCompleted: number;
    avgClosingTime: number;
  }[];
}

// Interface for the raw response from Supabase
interface CRAnalyticsResponse {
  id: string;
  cr_name: string;
  cr_batch: string;
  tickets_raised: number;
  tickets_closed: number;
  total_students: number;
  students_with_tickets: number;
  avg_response_time: string;
  avg_completion_time: string;
  satisfied_count: number;
  unsatisfied_count: number;
  monthly_data: Json;
}

// Interface for the expected structure of each monthly data item
interface MonthlyDataItem {
  month: string;
  ticketsCompleted: number;
  avgClosingTime: number;
}

export function CRDataAnalytics() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [analyticsData, setAnalyticsData] = useState<CRAnalytics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  const COLORS = ['#00C49F', '#FF8042'];

  // Fetch CR Analytics Data
  useEffect(() => {
    const fetchCRAnalytics = async () => {
      try {
        const { data, error } = await supabase.rpc('get_cr_analytics');
        
        if (error) throw error;
        
        if (data && data.length > 0) {
          // Parse the monthly_data JSON into the expected format
          const rawData = data[0] as CRAnalyticsResponse;
          
          // First, ensure monthly_data is an array
          const monthlyDataArray = Array.isArray(rawData.monthly_data) 
            ? rawData.monthly_data 
            : [];
          
          // Then, map each item with proper type casting
          const parsedMonthlyData: MonthlyDataItem[] = monthlyDataArray.map(item => {
            // Since we can't directly access properties on Json type, we need to cast
            const jsonItem = item as Record<string, unknown>;
            return {
              month: jsonItem.month as string,
              ticketsCompleted: Number(jsonItem.ticketsCompleted) || 0,
              avgClosingTime: Number(jsonItem.avgClosingTime) || 0
            };
          });
          
          // Create a properly typed CRAnalytics object
          const typedData: CRAnalytics = {
            ...rawData,
            monthly_data: parsedMonthlyData
          };
          
          setAnalyticsData(typedData);
        }
      } catch (error) {
        console.error('Error fetching CR analytics:', error);
        toast({
          title: "Error",
          description: "Failed to load CR analytics data",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchCRAnalytics();
  }, []);

  if (isLoading) {
    return (
      <Card className="bg-dark-surface border-dark-border">
        <CardContent className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
        </CardContent>
      </Card>
    );
  }

  if (!analyticsData) {
    return (
      <Card className="bg-dark-surface border-dark-border">
        <CardContent className="text-center text-dark-text-secondary p-6">
          No CR analytics data available.
        </CardContent>
      </Card>
    );
  }

  // Prepare data for charts
  const pieData = [
    { name: 'Satisfied', value: analyticsData.satisfied_count },
    { name: 'Unsatisfied', value: analyticsData.unsatisfied_count }
  ];

  const monthlyTicketsData = analyticsData.monthly_data || [];
  const monthlyClosingTimeData = analyticsData.monthly_data || [];

  return (
    <Card className="bg-dark-surface border-dark-border">
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-lg">CR Performance Analytics</CardTitle>
            <span className="text-sm text-dark-text-secondary">
              {analyticsData.cr_name} - {analyticsData.cr_batch}
            </span>
          </div>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm">
              {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
          </CollapsibleTrigger>
        </CardHeader>
        
        <CollapsibleContent>
          <CardContent className="px-4 pb-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="p-3 bg-dark-bg rounded-md">
                <div className="text-2xl font-bold">{analyticsData.tickets_raised}</div>
                <div className="text-xs text-dark-text-secondary">Tickets Raised This Month</div>
              </div>
              <div className="p-3 bg-dark-bg rounded-md">
                <div className="text-2xl font-bold">{analyticsData.tickets_closed}</div>
                <div className="text-xs text-dark-text-secondary">Tickets Closed This Month</div>
              </div>
              <div className="p-3 bg-dark-bg rounded-md">
                <div className="text-2xl font-bold">{analyticsData.students_with_tickets}</div>
                <div className="text-xs text-dark-text-secondary">Students Who Raised Tickets</div>
              </div>
              <div className="p-3 bg-dark-bg rounded-md">
                <div className="text-2xl font-bold">{analyticsData.avg_response_time}</div>
                <div className="text-xs text-dark-text-secondary">Average Response Time</div>
              </div>
              <div className="p-3 bg-dark-bg rounded-md">
                <div className="text-2xl font-bold">{analyticsData.avg_completion_time}</div>
                <div className="text-xs text-dark-text-secondary">Average Completion Time</div>
              </div>
              <div className="p-3 bg-dark-bg rounded-md">
                <div className="text-2xl font-bold">{analyticsData.total_students}</div>
                <div className="text-xs text-dark-text-secondary">Total Students in Batch</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              <div>
                <h4 className="text-sm font-medium mb-3">Satisfaction Rate</h4>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-3">Tickets Completed</h4>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={monthlyTicketsData}
                      margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                      <XAxis dataKey="month" stroke="#888" />
                      <YAxis stroke="#888" />
                      <Tooltip contentStyle={{ backgroundColor: '#333', border: 'none' }} />
                      <Bar dataKey="ticketsCompleted" name="Tickets Completed" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="text-sm font-medium mb-3">Average Closing Time (Days)</h4>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyClosingTimeData}
                    margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                    <XAxis dataKey="month" stroke="#888" />
                    <YAxis stroke="#888" />
                    <Tooltip contentStyle={{ backgroundColor: '#333', border: 'none' }} />
                    <Bar dataKey="avgClosingTime" name="Avg. Closing Time (Days)" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
