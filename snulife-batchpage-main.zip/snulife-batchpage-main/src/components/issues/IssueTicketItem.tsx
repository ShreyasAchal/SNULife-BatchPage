
import React, { useState } from "react";
import { format } from "date-fns";
import { ChevronDown, ChevronUp, FileText, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { supabase } from "@/integrations/supabase/client";
import { IssueTicket } from "@/types/issue";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Table, TableCell, TableRow } from "@/components/ui/table";

interface IssueTicketItemProps {
  ticket: IssueTicket;
  isCrMode?: boolean;
  onStatusChange?: (id: string, newStatus: string) => void;
  onCloseTicket?: (id: string) => void;
}

const tagColors: Record<string, string> = {
  "Academic": "bg-amber-500",
  "Attendance": "bg-purple-500",
  "Query": "bg-blue-500",
  "Clarification": "bg-green-500",
  "Request": "bg-pink-500",
  "Technical": "bg-red-500",
  "Others": "bg-gray-500"
};

const statusColors: Record<string, string> = {
  "Created": "bg-gray-500/20 text-gray-300",
  "Acknowledged": "bg-yellow-500/20 text-yellow-300",
  "Ongoing": "bg-green-500/20 text-green-300",
  "Closed": "bg-blue-500/20 text-blue-300"
};

export function IssueTicketItem({ ticket, isCrMode = false, onStatusChange, onCloseTicket }: IssueTicketItemProps) {
  const [deleting, setDeleting] = useState(false);

  const markAsRead = async () => {
    if (!ticket.is_read) {
      try {
        // Skip for sample tickets
        if (ticket.id.startsWith('sample-')) {
          return;
        }
        await supabase.rpc('update_issue_read_status', { 
          issue_id: ticket.id,
          read_status: true 
        });
      } catch (error) {
        console.error('Error marking ticket as read:', error);
      }
    }
  };

  // Prevents table row from marking as read or triggering row click when opening dialog
  const handleDialogTriggerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // No need to call preventDefault, just stops parent events
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy HH:mm');
    } catch (e) {
      return "Invalid date";
    }
  };

  // Format the response time if available
  const formatResponseTime = (dateString: string | null | undefined) => {
    if (!dateString) return "Not specified";
    try {
      const date = new Date(dateString);
      return format(date, 'MMM dd, yyyy HH:mm');
    } catch (e) {
      return "Invalid date";
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (ticket.id.startsWith('sample-')) {
      window.dispatchEvent(
        new CustomEvent('sonner:toast', { 
          detail: { 
            title: 'Demo Mode', 
            description: 'Sample ticket cannot be deleted.' 
          }
        })
      );
      return;
    }
    setDeleting(true);
    try {
      const { error } = await supabase
        .from('issues')
        .delete()
        .eq('id', ticket.id);

      if (error) throw error;

      window.dispatchEvent(
        new CustomEvent('sonner:toast', { 
          detail: { 
            title: 'Deleted',
            description: 'Ticket successfully deleted.'
          }
        })
      );
    } catch (err) {
      window.dispatchEvent(
        new CustomEvent('sonner:toast', { 
          detail: { 
            title: 'Error',
            description: 'There was a problem deleting the ticket.',
            variant: 'destructive'
          }
        })
      );
    }
    setDeleting(false);
  };

  return (
    <TableRow 
      className={`hover:bg-dark-bg/30 transition-all duration-200 ${!ticket.is_read ? 'bg-dark-bg/10' : ''}`}
      onClick={markAsRead}
    >
      <TableCell className="font-medium">{ticket.ticket_number}</TableCell>
      <TableCell>{formatDate(ticket.created_at)}</TableCell>
      <TableCell>{ticket.title}</TableCell>
      <TableCell>
        <Dialog>
          <DialogTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center"
              onClick={handleDialogTriggerClick}
              type="button"
              tabIndex={0}
            >
              <FileText className="h-4 w-4 mr-1" />
              View details
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Ticket Details</DialogTitle>
              <DialogDescription>
                All information regarding request #{ticket.ticket_number}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <h4 className="text-sm font-medium mb-1">Title:</h4>
                <div className="text-white/90 text-base">{ticket.title}</div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-1">Creation Time:</h4>
                <div className="text-white/90 text-sm">{formatDate(ticket.created_at)}</div>
              </div>
              <div className="flex flex-wrap gap-6">
                <div>
                  <h4 className="text-sm font-medium mb-1">Category:</h4>
                  <Badge className={`${tagColors[ticket.category] || "bg-gray-500"} bg-opacity-20`}>
                    {ticket.category}
                  </Badge>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Course:</h4>
                  <span className="text-white/90 text-sm">{ticket.course}</span>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Status:</h4>
                  <Badge className={`${statusColors[ticket.status]}`}>{ticket.status}</Badge>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-1">Description:</h4>
                <p className="text-white/90 text-sm whitespace-pre-wrap">
                  {ticket.description}
                </p>
              </div>
              {ticket.cr_remarks && (
                <div>
                  <h4 className="text-sm font-medium">CR Remarks:</h4>
                  <p className="text-sm mt-1 p-2 bg-gray-800 rounded">{ticket.cr_remarks}</p>
                </div>
              )}
              <div>
                <h4 className="text-sm font-medium mb-1">Requested Response Time:</h4>
                <div className="text-white/90 text-sm">{formatResponseTime(ticket.requested_response_time)}</div>
              </div>
              <div className="text-xs text-dark-text-secondary mt-2">
                {isCrMode && <span className="mr-2">Student: {ticket.student_name}</span>}
                {ticket.closed_at && (
                  <span>Closed {formatDate(ticket.closed_at)}</span>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </TableCell>
      <TableCell>
        <Badge className={`${statusColors[ticket.status]}`}>{ticket.status}</Badge>
      </TableCell>
      <TableCell>
        <Badge className={`${tagColors[ticket.category] || "bg-gray-500"} bg-opacity-20`}>
          {ticket.category}
        </Badge>
      </TableCell>
      <TableCell>{ticket.course}</TableCell>
      <TableCell>{formatResponseTime(ticket.requested_response_time)}</TableCell>
      {isCrMode && ticket.status !== "Closed" && (
        <TableCell>
          <div className="flex flex-wrap gap-2">
            {onStatusChange && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  className={`${statusColors["Created"]} border-none`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onStatusChange(ticket.id, "Created");
                  }}
                  type="button"
                >
                  Created
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className={`${statusColors["Acknowledged"]} border-none`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onStatusChange(ticket.id, "Acknowledged");
                  }}
                  type="button"
                >
                  Acknowledged
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className={`${statusColors["Ongoing"]} border-none`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onStatusChange(ticket.id, "Ongoing");
                  }}
                  type="button"
                >
                  Ongoing
                </Button>
              </>
            )}
            {onCloseTicket && (
              <Button
                variant="destructive"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTicket(ticket.id);
                }}
                type="button"
              >
                Close Ticket
              </Button>
            )}
            {/* Delete Button for CR mode (for both ongoing and completed) */}
            <Button
              variant="outline"
              size="sm"
              className="border-red-500 text-red-500"
              onClick={handleDelete}
              disabled={deleting}
              type="button"
              tabIndex={0}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              {deleting ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </TableCell>
      )}
      {!isCrMode && !ticket.is_read && (
        <TableCell>
          <Badge className="bg-blue-500/20 text-blue-300">New</Badge>
        </TableCell>
      )}
    </TableRow>
  );
}
