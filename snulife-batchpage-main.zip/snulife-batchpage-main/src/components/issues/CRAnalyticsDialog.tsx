
import React from "react";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger
} from "@/components/ui/dialog";
import { CRDataAnalytics } from "./CRDataAnalytics";
import { BarChart2 } from "lucide-react";

export function CRAnalyticsDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <BarChart2 className="h-4 w-4" />
          View Analytics
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>CR Analytics Dashboard</DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          <CRDataAnalytics />
        </div>
      </DialogContent>
    </Dialog>
  );
}
