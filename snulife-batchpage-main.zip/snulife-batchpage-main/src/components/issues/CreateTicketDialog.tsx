
import React from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { useForm } from "react-hook-form";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Calendar } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { format, addDays, isToday } from "date-fns";
import { cn } from "@/lib/utils";
import { Calendar as CalendarComponent } from "../ui/calendar";

interface CreateTicketDialogProps {
  onTicketCreated?: () => void;
}

export function CreateTicketDialog({ onTicketCreated }: CreateTicketDialogProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const { toast } = useToast();
  const [timeSelected, setTimeSelected] = React.useState("");
  const [dateSelected, setDateSelected] = React.useState<Date | undefined>(undefined);

  const categories = ["Academic", "Attendance", "Query", "Clarification", "Request", "Technical"];
  const courses = [
    "CSD317: Introduction to Database Systems",
    "CSD204: Operating Systems",
    "CSD210: Introduction to Probability and Statistics",
    "CSD212: Digital Image Processing",
    "DES211: Concept and Creativity in Design"
  ];
  const times = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"];

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      title: "",
      description: "",
      category: "Academic",
      course: courses[0],
    }
  });

  const onSubmit = async (data: any) => {
    if (!dateSelected || !timeSelected) {
      toast({
        title: "Missing Field",
        description: "Please select both date and time for requested response",
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    try {
      const [hours, minutes] = timeSelected.split(':');
      const responseDate = new Date(dateSelected);
      responseDate.setHours(parseInt(hours), parseInt(minutes));
      
      // Direct insert to issues table instead of using RPC
      const { error } = await supabase
        .from('issues')
        .insert({
          title: data.title,
          description: data.description,
          category: data.category,
          course: data.course,
          requested_response_time: responseDate.toISOString(),
          student_name: "Current User", // Replace with actual user name if authentication is added
          status: "Created",
          is_read: false
        });
      
      if (error) throw error;
      
      toast({
        title: "Request Submitted",
        description: "Your request has been submitted successfully."
      });
      
      reset();
      setIsOpen(false);
      setDateSelected(undefined);
      setTimeSelected("");
      
      if (onTicketCreated) {
        onTicketCreated();
      }
    } catch (error) {
      console.error("Error submitting request:", error);
      toast({
        title: "Error",
        description: "Failed to submit your request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const disableDate = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const maxDate = addDays(today, 7);
    const isBeforeToday = date < today;
    const isAfterMaxDate = date > maxDate;
    const isTodayDate = isToday(date);
    
    return isBeforeToday || isAfterMaxDate || isTodayDate;
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Request
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Request</DialogTitle>
          <DialogDescription>
            Fill out this form to submit a new request or issue.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                {...register("title", { required: true })}
                className={errors.title ? "border-red-500" : ""}
              />
              {errors.title && (
                <p className="text-red-500 text-xs">Title is required</p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                {...register("description", { required: true })}
                className={errors.description ? "border-red-500" : ""}
              />
              {errors.description && (
                <p className="text-red-500 text-xs">Description is required</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <Select
                  defaultValue="Academic"
                  onValueChange={(value) => {
                    const event = {
                      target: { value }
                    } as React.ChangeEvent<HTMLSelectElement>;
                    register("category").onChange(event);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="course">Course</Label>
                <Select
                  defaultValue={courses[0]}
                  onValueChange={(value) => {
                    const event = {
                      target: { value }
                    } as React.ChangeEvent<HTMLSelectElement>;
                    register("course").onChange(event);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((course) => (
                      <SelectItem key={course} value={course}>
                        {course}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-2">
              <Label>Requested Response Time</Label>
              <div className="grid grid-cols-2 gap-4">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateSelected && "text-muted-foreground"
                      )}
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      {dateSelected ? format(dateSelected, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent
                      mode="single"
                      selected={dateSelected}
                      onSelect={setDateSelected}
                      disabled={disableDate}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
                
                <Select
                  value={timeSelected}
                  onValueChange={setTimeSelected}
                  disabled={!dateSelected}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Time" />
                  </SelectTrigger>
                  <SelectContent>
                    {times.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {!dateSelected && !timeSelected && (
                <p className="text-xs text-muted-foreground">
                  Select a date (within the next 7 days, excluding today) and time for your response
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Submitting..." : "Submit Request"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
