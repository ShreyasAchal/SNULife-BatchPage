
import React from "react";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger
} from "@/components/ui/dialog";
import { HelpCircle } from "lucide-react";

export function HowToUseDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-2">
          <HelpCircle className="h-4 w-4" />
          How to Use
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>How to Use the Request Tracker</DialogTitle>
          <DialogDescription>
            Guide to submitting and monitoring your academic concerns
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 mt-4">
          <p>Use this Request Tracker to submit and monitor all your academic concerns.</p>
          <ol className="list-decimal ml-5 space-y-2">
            <li>Click on "New Request" to submit a concern.</li>
            <li>Check "Ongoing Requests" for items being processed.</li>
            <li>View "Completed Requests" for resolved concerns.</li>
            <li>Click on any request to view full details.</li>
          </ol>
          <p>The Class Representative will review and process your requests.</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
