
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogTrigger
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Edit, 
  Plus, 
  X,
  Trash2 
} from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

interface CourseTA {
  id: string;
  course_id: string;
  name: string;
  email: string | null;
  department: string | null;
  graduation_year: string | null;
  office: string | null;
  role: string;
}

interface CourseTAInfoProps {
  courseId: string;
  isCRMode: boolean;
}

const CourseTAInfo: React.FC<CourseTAInfoProps> = ({ courseId, isCRMode }) => {
  const [isAddingTA, setIsAddingTA] = useState(false);
  const [editingTA, setEditingTA] = useState<CourseTA | null>(null);
  const [formData, setFormData] = useState<Partial<CourseTA>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch TAs data
  const { 
    data: tas = [], 
    isLoading: isLoadingTAs,
  } = useQuery({
    queryKey: ['courseTAs', courseId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('course_tas')
        .select('*')
        .eq('course_id', courseId)
        .order('name', { ascending: true });
      
      if (error) throw new Error(error.message);
      return data as CourseTA[];
    }
  });

  // Create TA mutation
  const createTAMutation = useMutation({
    mutationFn: async (newTA: Partial<CourseTA>) => {
      const { data, error } = await supabase
        .from('course_tas')
        .insert({
          course_id: courseId,
          name: newTA.name || 'TA',
          email: newTA.email,
          department: newTA.department,
          graduation_year: newTA.graduation_year,
          office: newTA.office,
          role: newTA.role || 'Student Teaching Assistant'
        })
        .select()
        .single();
      
      if (error) throw new Error(error.message);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courseTAs', courseId] });
      toast({
        title: "Teaching Assistant added",
        description: "Teaching Assistant has been added successfully."
      });
      setIsAddingTA(false);
      setFormData({});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add Teaching Assistant: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Update TA mutation
  const updateTAMutation = useMutation({
    mutationFn: async (updatedTA: CourseTA) => {
      const { data, error } = await supabase
        .from('course_tas')
        .update({
          name: updatedTA.name,
          email: updatedTA.email,
          department: updatedTA.department,
          graduation_year: updatedTA.graduation_year,
          office: updatedTA.office,
          role: updatedTA.role
        })
        .eq('id', updatedTA.id)
        .select()
        .single();
      
      if (error) throw new Error(error.message);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courseTAs', courseId] });
      toast({
        title: "Teaching Assistant updated",
        description: "Teaching Assistant has been updated successfully."
      });
      setEditingTA(null);
      setFormData({});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update Teaching Assistant: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Delete TA mutation
  const deleteTAMutation = useMutation({
    mutationFn: async (taId: string) => {
      const { error } = await supabase
        .from('course_tas')
        .delete()
        .eq('id', taId);
      
      if (error) throw new Error(error.message);
      return taId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courseTAs', courseId] });
      toast({
        title: "Teaching Assistant removed",
        description: "Teaching Assistant has been removed successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to remove Teaching Assistant: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleAddClick = () => {
    setFormData({
      name: '',
      email: '',
      department: '',
      graduation_year: '',
      office: '',
      role: 'Student Teaching Assistant'
    });
    setIsAddingTA(true);
  };

  const handleEditClick = (ta: CourseTA) => {
    setEditingTA(ta);
    setFormData({
      name: ta.name,
      email: ta.email || '',
      department: ta.department || '',
      graduation_year: ta.graduation_year || '',
      office: ta.office || '',
      role: ta.role
    });
  };

  const handleDeleteTA = (taId: string) => {
    if (window.confirm('Are you sure you want to remove this Teaching Assistant?')) {
      deleteTAMutation.mutate(taId);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRoleChange = (value: string) => {
    setFormData(prev => ({ ...prev, role: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name) {
      toast({
        title: "Validation Error",
        description: "Teaching Assistant name is required",
        variant: "destructive"
      });
      return;
    }
    
    if (editingTA) {
      updateTAMutation.mutate({
        ...editingTA,
        name: formData.name || editingTA.name,
        email: formData.email || null,
        department: formData.department || null,
        graduation_year: formData.graduation_year || null,
        office: formData.office || null,
        role: formData.role || editingTA.role
      });
    } else {
      createTAMutation.mutate(formData);
    }
  };

  // Display skeleton while loading
  if (isLoadingTAs) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>Teaching Assistants</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
            <div className="h-4 bg-gray-700 rounded w-1/2"></div>
            <div className="h-4 bg-gray-700 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Teaching Assistants</span>
          {isCRMode && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0" 
              onClick={handleAddClick}
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {tas.length > 0 ? (
          <div className="space-y-4">
            {tas.map(ta => (
              <div key={ta.id} className="p-3 bg-secondary/20 rounded-md">
                <div className="flex justify-between items-start">
                  <div className="space-y-1 text-sm">
                    <div className="font-semibold">{ta.name}</div>
                    <div className="text-xs text-muted-foreground">{ta.role}</div>
                    {ta.email && <div><span className="text-xs">Email:</span> {ta.email}</div>}
                    {ta.department && (
                      <div>
                        <span className="text-xs">Department:</span> {ta.department}
                        {ta.graduation_year && ` (${ta.graduation_year})`}
                      </div>
                    )}
                    {ta.office && <div><span className="text-xs">Office:</span> {ta.office}</div>}
                  </div>
                  {isCRMode && (
                    <div className="flex space-x-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-7 w-7 p-0" 
                        onClick={() => handleEditClick(ta)}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive/90" 
                        onClick={() => handleDeleteTA(ta.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4 text-muted-foreground">
            {isCRMode ? (
              <Button variant="outline" size="sm" onClick={handleAddClick}>
                Add Teaching Assistant
              </Button>
            ) : (
              "No teaching assistants available."
            )}
          </div>
        )}

        {isCRMode && tas.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full" 
              onClick={handleAddClick}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add More
            </Button>
          </div>
        )}
      </CardContent>

      <Dialog open={isAddingTA} onOpenChange={setIsAddingTA}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Teaching Assistant</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-3">
              <div className="space-y-1">
                <label htmlFor="name" className="text-sm font-medium">
                  Name *
                </label>
                <Input 
                  id="name" 
                  name="name" 
                  value={formData.name || ''} 
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <Input 
                  id="email" 
                  name="email" 
                  type="email" 
                  value={formData.email || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="department" className="text-sm font-medium">
                  Department
                </label>
                <Input 
                  id="department" 
                  name="department" 
                  value={formData.department || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="graduation_year" className="text-sm font-medium">
                  Year
                </label>
                <Input 
                  id="graduation_year" 
                  name="graduation_year" 
                  value={formData.graduation_year || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="office" className="text-sm font-medium">
                  Office (Optional)
                </label>
                <Input 
                  id="office" 
                  name="office" 
                  value={formData.office || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="role" className="text-sm font-medium">
                  Role
                </label>
                <Select 
                  onValueChange={handleRoleChange} 
                  defaultValue={formData.role || 'Student Teaching Assistant'}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Student Teaching Assistant">
                      Student Teaching Assistant
                    </SelectItem>
                    <SelectItem value="LASC Tutor">
                      LASC Tutor
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddingTA(false)}>
                Cancel
              </Button>
              <Button type="submit">
                Add
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingTA} onOpenChange={(open) => !open && setEditingTA(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Teaching Assistant</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-3">
              <div className="space-y-1">
                <label htmlFor="edit-name" className="text-sm font-medium">
                  Name *
                </label>
                <Input 
                  id="edit-name" 
                  name="name" 
                  value={formData.name || ''} 
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="edit-email" className="text-sm font-medium">
                  Email
                </label>
                <Input 
                  id="edit-email" 
                  name="email" 
                  type="email" 
                  value={formData.email || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="edit-department" className="text-sm font-medium">
                  Department
                </label>
                <Input 
                  id="edit-department" 
                  name="department" 
                  value={formData.department || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="edit-graduation_year" className="text-sm font-medium">
                  Year
                </label>
                <Input 
                  id="edit-graduation_year" 
                  name="graduation_year" 
                  value={formData.graduation_year || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="edit-office" className="text-sm font-medium">
                  Office (Optional)
                </label>
                <Input 
                  id="edit-office" 
                  name="office" 
                  value={formData.office || ''} 
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-1">
                <label htmlFor="edit-role" className="text-sm font-medium">
                  Role
                </label>
                <Select 
                  onValueChange={handleRoleChange} 
                  defaultValue={formData.role || 'Student Teaching Assistant'}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Student Teaching Assistant">
                      Student Teaching Assistant
                    </SelectItem>
                    <SelectItem value="LASC Tutor">
                      LASC Tutor
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingTA(null)}>
                Cancel
              </Button>
              <Button type="submit">
                Update
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default CourseTAInfo;
