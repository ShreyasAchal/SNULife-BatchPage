
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Edit, Save, X, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CourseInstructor {
  id: string;
  name: string;
  email: string | null;
  office: string | null;
  office_hours: string | null;
  website: string | null;
}

interface CourseInstructorInfoProps {
  courseId: string;
  isCRMode: boolean;
}

const CourseInstructorInfo: React.FC<CourseInstructorInfoProps> = ({ courseId, isCRMode }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedInstructor, setEditedInstructor] = useState<Partial<CourseInstructor>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: instructor, isLoading } = useQuery({
    queryKey: ['course-instructor', courseId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('course_instructors')
        .select('*')
        .eq('course_id', courseId)
        .single();
      if (error) throw error;
      // Remove snu_page and rslookup_page fields if present in legacy data
      const { snu_page, rslookup_page, ...rest } = data;
      return rest as CourseInstructor;
    }
  });

  const updateInstructorMutation = useMutation({
    mutationFn: async (instructor: CourseInstructor) => {
      const { data, error } = await supabase
        .from('course_instructors')
        .update({
          name: instructor.name,
          email: instructor.email,
          office: instructor.office,
          office_hours: instructor.office_hours,
          website: instructor.website,
        })
        .eq('id', instructor.id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['course-instructor', courseId] });
      setIsEditing(false);
      setEditedInstructor({});
      toast({
        title: "Instructor Info Updated",
        description: "The instructor information has been updated successfully."
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, field: string) => {
    setEditedInstructor({
      ...editedInstructor,
      [field]: e.target.value,
    });
  };

  const handleSave = () => {
    if (!instructor) return;
    updateInstructorMutation.mutate({
      ...instructor,
      ...editedInstructor,
    } as CourseInstructor);
  };

  if (isLoading) {
    return <div className="text-center py-4">Loading instructor info...</div>;
  }

  return (
    <Card className="bg-dark-bg">
      <CardHeader className="flex items-center justify-between">
        <CardTitle>Instructor Info</CardTitle>
        {isCRMode && !isEditing && (
          <Button variant="ghost" size="sm" onClick={() => {
            setIsEditing(true);
            setEditedInstructor(instructor);
          }}>
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
        )}
        {isCRMode && isEditing && (
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm" onClick={() => setIsEditing(false)}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button variant="outline" size="sm" onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {instructor && !isEditing ? (
          <div className="space-y-2">
            <div className="text-sm">
              <span className="font-medium">Name:</span> {instructor.name}
            </div>
            <div className="text-sm">
              <span className="font-medium">Email:</span> {instructor.email || 'N/A'}
            </div>
            <div className="text-sm">
              <span className="font-medium">Office:</span> {instructor.office || 'N/A'}
            </div>
            <div className="text-sm">
              <span className="font-medium">Office Hours:</span> {instructor.office_hours || 'N/A'}
            </div>
            <div className="flex items-center space-x-3 mt-2">
              <span className="font-medium text-sm">Website:</span>
              {instructor.website ? (
                <>
                  <span className="text-sm text-blue-200 underline break-all">{instructor.website}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="px-2 py-1"
                    onClick={() => window.open(instructor.website as string, '_blank', 'noopener,noreferrer')}
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Open
                  </Button>
                </>
              ) : (
                <span className="text-sm">N/A</span>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <Label htmlFor="name" className="text-xs">Name</Label>
              <Input
                id="name"
                value={editedInstructor.name || ''}
                onChange={(e) => handleInputChange(e, 'name')}
                className="h-8 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="email" className="text-xs">Email</Label>
              <Input
                id="email"
                value={editedInstructor.email || ''}
                onChange={(e) => handleInputChange(e, 'email')}
                className="h-8 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="office" className="text-xs">Office</Label>
              <Input
                id="office"
                value={editedInstructor.office || ''}
                onChange={(e) => handleInputChange(e, 'office')}
                className="h-8 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="office_hours" className="text-xs">Office Hours</Label>
              <Input
                id="office_hours"
                value={editedInstructor.office_hours || ''}
                onChange={(e) => handleInputChange(e, 'office_hours')}
                className="h-8 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="website" className="text-xs">Website</Label>
              <Input
                id="website"
                value={editedInstructor.website || ''}
                onChange={(e) => handleInputChange(e, 'website')}
                className="h-8 text-sm"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CourseInstructorInfo;
