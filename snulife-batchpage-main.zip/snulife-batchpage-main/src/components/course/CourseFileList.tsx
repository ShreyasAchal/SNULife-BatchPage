
import React from 'react';
import { FileText, Image, Trash2 } from 'lucide-react';
import { Button } from '../ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

interface CourseFile {
  id: string;
  file_name: string;
  file_type: string;
  file_url: string;
}

interface CourseFileListProps {
  courseId: string;
  folderId: string;
  isCRMode: boolean;
}

const CourseFileList: React.FC<CourseFileListProps> = ({ courseId, folderId, isCRMode }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: files = [], isLoading } = useQuery({
    queryKey: ['course-files', folderId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('course_files')
        .select('*')
        .eq('folder_id', folderId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as CourseFile[];
    }
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const file = files.find(f => f.id === fileId);
      if (!file) return;

      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('course-files')
        .remove([file.file_url]);
      
      if (storageError) throw storageError;

      // Delete from database
      const { error: dbError } = await supabase
        .from('course_files')
        .delete()
        .eq('id', fileId);
      
      if (dbError) throw dbError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['course-files', folderId] });
      toast({
        title: "File deleted",
        description: "The file has been removed successfully."
      });
    }
  });

  const handleDownload = async (file: CourseFile) => {
    try {
      const { data, error } = await supabase.storage
        .from('course-files')
        .download(file.file_url);
      
      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.file_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Download failed",
        description: "There was an error downloading the file.",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return <div className="text-center py-4">Loading files...</div>;
  }

  return (
    <div className="space-y-2">
      {files.map((file) => (
        <div
          key={file.id}
          className="flex items-center justify-between p-2 rounded-md hover:bg-accent/50"
        >
          <div 
            className="flex items-center space-x-2 cursor-pointer"
            onClick={() => handleDownload(file)}
          >
            {file.file_type.includes('image') ? (
              <Image className="h-4 w-4" />
            ) : (
              <FileText className="h-4 w-4" />
            )}
            <span className="text-sm">{file.file_name}</span>
          </div>
          
          {isCRMode && (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 text-red-400 hover:text-red-300"
              onClick={() => deleteFileMutation.mutate(file.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      ))}
      
      {files.length === 0 && (
        <div className="text-center py-4 text-muted-foreground">
          No files uploaded yet
        </div>
      )}
    </div>
  );
};

export default CourseFileList;
