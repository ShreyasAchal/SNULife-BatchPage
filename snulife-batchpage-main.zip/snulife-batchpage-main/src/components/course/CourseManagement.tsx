
import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Trash2, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../ui/popover";

interface Course {
  id: string;
  code: string;
  name: string;
}

interface CourseManagementProps {
  courses: Course[];
  isCRMode: boolean;
}

const CourseManagement: React.FC<CourseManagementProps> = ({ courses, isCRMode }) => {
  const [isAddingCourse, setIsAddingCourse] = useState(false);
  const [newCourseCode, setNewCourseCode] = useState('');
  const [newCourseName, setNewCourseName] = useState('');
  const [deletingCourse, setDeletingCourse] = useState<Course | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createCourseMutation = useMutation({
    mutationFn: async (newCourse: { code: string; name: string }) => {
      const { data, error } = await supabase
        .from('courses')
        .insert({
          code: newCourse.code,
          name: newCourse.name
        })
        .select()
        .single();
      
      if (error) throw error;
      
      // Also create default instructor and TA entries
      if (data) {
        // Add a default instructor
        await supabase
          .from('course_instructors')
          .insert({
            course_id: data.id,
            name: 'XYZ',
            email: 'instructor@example.com',
            office: 'Office XYZ',
            office_hours: 'Mon-Fri 10-12'
          });
        
        // Add a default TA
        await supabase
          .from('course_tas')
          .insert({
            course_id: data.id,
            name: 'XYZ',
            email: 'ta@example.com',
            department: 'Department XYZ',
            role: 'Student Teaching Assistant'
          });
      }
      
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courses'] });
      setIsAddingCourse(false);
      setNewCourseCode('');
      setNewCourseName('');
      toast({
        title: "Course Added",
        description: "The course has been added successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add course: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const deleteCourseMutation = useMutation({
    mutationFn: async (courseId: string) => {
      // First delete related records
      await supabase.from('course_instructors').delete().eq('course_id', courseId);
      await supabase.from('course_tas').delete().eq('course_id', courseId);
      await supabase.from('course_folders').delete().eq('course_id', courseId);
      await supabase.from('posts').update({ course_id: null }).eq('course_id', courseId);
      await supabase.from('deadlines').update({ course_id: null }).eq('course_id', courseId);
      
      // Then delete the course
      const { error } = await supabase
        .from('courses')
        .delete()
        .eq('id', courseId);
      
      if (error) throw error;
      return courseId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courses'] });
      setDeletingCourse(null);
      toast({
        title: "Course Deleted",
        description: "The course has been deleted successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete course: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleAddCourse = () => {
    if (!newCourseCode.trim() || !newCourseName.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide both course code and name.",
        variant: "destructive"
      });
      return;
    }

    // Check for duplicates
    const isDuplicate = courses.some(
      course => course.code.toLowerCase() === newCourseCode.toLowerCase()
    );

    if (isDuplicate) {
      toast({
        title: "Duplicate Course",
        description: "A course with this code already exists.",
        variant: "destructive"
      });
      return;
    }

    createCourseMutation.mutate({
      code: newCourseCode,
      name: newCourseName
    });
  };

  const handleDeleteCourse = (course: Course) => {
    setDeletingCourse(course);
  };

  const confirmDeleteCourse = () => {
    if (deletingCourse) {
      deleteCourseMutation.mutate(deletingCourse.id);
    }
  };

  if (!isCRMode) {
    return null;
  }

  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-medium text-dark-text-secondary">Course Management</h3>
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setIsAddingCourse(true)}
          className="flex items-center text-xs"
        >
          <Plus className="h-3.5 w-3.5 mr-1" />
          Add Course
        </Button>
      </div>
      
      {isAddingCourse && (
        <div className="bg-dark-bg p-3 rounded-md border border-dark-border mb-4">
          <h4 className="text-sm font-medium mb-2">Add New Course</h4>
          <div className="space-y-3 mb-3">
            <div>
              <Label htmlFor="courseCode" className="text-xs">Course Code</Label>
              <Input
                id="courseCode"
                value={newCourseCode}
                onChange={(e) => setNewCourseCode(e.target.value)}
                placeholder="e.g. CS101"
                className="h-8 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="courseName" className="text-xs">Course Name</Label>
              <Input
                id="courseName"
                value={newCourseName}
                onChange={(e) => setNewCourseName(e.target.value)}
                placeholder="e.g. Introduction to Computer Science"
                className="h-8 text-sm"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsAddingCourse(false)}
              className="text-xs h-8"
            >
              Cancel
            </Button>
            <Button 
              size="sm" 
              onClick={handleAddCourse}
              className="text-xs h-8"
            >
              Add Course
            </Button>
          </div>
        </div>
      )}
      
      <div className="space-y-1">
        {courses.map((course) => (
          <div 
            key={course.id}
            className="flex items-center justify-between py-1 px-2 text-sm rounded hover:bg-dark-bg/50"
          >
            <span className="text-xs">
              <span className="font-medium">{course.code}</span>
              <span className="text-dark-text-secondary ml-2">{course.name}</span>
            </span>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                  <Trash2 className="h-3.5 w-3.5 text-red-400" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="bg-dark-surface border-dark-border w-64 p-3">
                <div className="space-y-2">
                  <div className="flex items-start">
                    <AlertCircle className="h-4 w-4 text-red-500 mr-2 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium">Delete Course</h4>
                      <p className="text-xs text-dark-text-secondary">This will delete the course and all its folders. Posts and deadlines will be kept but disassociated from this course.</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setDeletingCourse(null)}
                      className="text-xs h-7"
                    >
                      Cancel
                    </Button>
                    <Button 
                      variant="destructive" 
                      size="sm" 
                      onClick={() => deleteCourseMutation.mutate(course.id)}
                      className="text-xs h-7"
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        ))}
      </div>
      
      <Dialog open={!!deletingCourse} onOpenChange={(open) => !open && setDeletingCourse(null)}>
        <DialogContent className="bg-dark-surface border-dark-border">
          <DialogHeader>
            <DialogTitle>Delete Course</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the course "{deletingCourse?.code}: {deletingCourse?.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => setDeletingCourse(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDeleteCourse}>
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CourseManagement;
