
import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Plus, FileText, Image, Loader2, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface CourseFileUploadProps {
  courseId: string;
  folderId: string;
  onFileUploaded: () => void;
}

const CourseFileUpload: React.FC<CourseFileUploadProps> = ({ courseId, folderId, onFileUploaded }) => {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    setIsUploading(true);
    
    try {
      // Upload file to storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${courseId}/${folderId}/${fileName}`;
      
      const { error: uploadError, data } = await supabase.storage
        .from('course-files')
        .upload(filePath, file);
      
      if (uploadError) throw uploadError;
      
      if (!data) throw new Error('Upload failed');
      
      // Create file record in database
      const { error: dbError } = await supabase
        .from('course_files')
        .insert({
          folder_id: folderId,
          course_id: courseId,
          file_name: file.name,
          file_type: file.type,
          file_url: data.path
        });
      
      if (dbError) throw dbError;
      
      toast({
        title: "File uploaded",
        description: "The file has been uploaded successfully."
      });
      
      onFileUploaded();
      
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading the file.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  return (
    <div className="mt-4">
      <Input
        type="file"
        accept=".pdf,image/*"
        className="hidden"
        id="file-upload"
        onChange={handleFileUpload}
        disabled={isUploading}
      />
      <label
        htmlFor="file-upload"
        className={`inline-flex items-center space-x-2 px-4 py-2 rounded-md border border-input 
          ${isUploading ? 'bg-muted cursor-not-allowed' : 'bg-background hover:bg-accent cursor-pointer'}`}
      >
        {isUploading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Plus className="h-4 w-4" />
        )}
        <span>Upload File</span>
      </label>
      <p className="text-xs text-muted-foreground mt-1">
        Supported: PDF and image files
      </p>
    </div>
  );
};

export default CourseFileUpload;
