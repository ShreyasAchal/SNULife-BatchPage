
import React from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';

// Define PostTag type
type PostTag = 'Assignment' | 'Quiz' | 'Exams' | 'Others';

interface Course {
  id: string;
  code: string;
  name: string;
}

interface DeadlineFormProps {
  deadline?: {
    id: string;
    title: string;
    course?: string;
    dueDate: string;
    dueTime: string;
    tag: string;
    completed?: boolean;
  };
  onSubmit: (data: any) => void;
  onCancel: () => void;
  courses: Course[];
}

const DeadlineForm: React.FC<DeadlineFormProps> = ({ deadline, onSubmit, onCancel, courses }) => {
  const form = useForm({
    defaultValues: deadline ? {
      title: deadline.title,
      course: deadline.course,
      dueDate: deadline.dueDate,
      dueTime: deadline.dueTime || '00:00',
      tag: deadline.tag,
      completed: deadline.completed || false,
    } : {
      title: '',
      course: '',
      dueDate: new Date().toISOString().split('T')[0],
      dueTime: '00:00',
      tag: 'Assignment',
      completed: false,
    }
  });

  const handleFormSubmit = form.handleSubmit((data) => {
    onSubmit(data);
  });

  return (
    <Card className="bg-dark-surface border-dark-border w-full mb-4">
      <CardHeader>
        <CardTitle>{deadline ? 'Edit Deadline' : 'New Deadline'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <label htmlFor="title" className="text-sm font-medium">Title</label>
              <Input
                id="title"
                placeholder="Enter deadline title"
                {...form.register('title', { required: true })}
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="course" className="text-sm font-medium">Course</label>
              <Select 
                defaultValue={form.getValues('course')}
                onValueChange={(value) => form.setValue('course', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select course" />
                </SelectTrigger>
                <SelectContent className="bg-dark-surface border-dark-border">
                  {courses.map(course => (
                    <SelectItem key={course.id} value={`${course.code}: ${course.name}`}>
                      {course.code}: {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 space-y-2">
                <label htmlFor="dueDate" className="text-sm font-medium">Due Date</label>
                <Input
                  id="dueDate"
                  type="date"
                  {...form.register('dueDate', { required: true })}
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="dueTime" className="text-sm font-medium">Time</label>
                <Input
                  id="dueTime"
                  type="time"
                  {...form.register('dueTime', { required: true })}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="tag" className="text-sm font-medium">Tag</label>
              <Select 
                defaultValue={form.getValues('tag')}
                onValueChange={(value) => form.setValue('tag', value as PostTag)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select tag" />
                </SelectTrigger>
                <SelectContent className="bg-dark-surface border-dark-border">
                  {['Assignment', 'Quiz', 'Exams', 'Others'].map((tag) => (
                    <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <input 
                type="checkbox" 
                id="completed" 
                className="rounded border-input h-4 w-4"
                checked={form.getValues('completed')}
                onChange={(e) => form.setValue('completed', e.target.checked)}
              />
              <label htmlFor="completed" className="text-sm font-medium">Mark as completed</label>
            </div>
            
            <div className="flex justify-end space-x-2 pt-2">
              <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
              <Button type="submit">{deadline ? 'Update' : 'Add'}</Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default DeadlineForm;
