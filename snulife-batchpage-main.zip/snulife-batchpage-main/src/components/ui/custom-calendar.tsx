
import React, { useState, useEffect } from "react";
import { 
  format, 
  startOfMonth,
  endOfMonth,
  startOfWeek, 
  endOfWeek,
  addDays,
  isSameMonth,
  isSameDay,
  eachDayOfInterval,
  addHours,
  getDay,
  parseISO,
  isWithinInterval
} from "date-fns";
import { cn } from "@/lib/utils";
import { ExternalLink, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { Button } from "./button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface RepoCourse {
  id: string;
  code: string;
  name: string;
}

interface CalendarEvent {
  date: Date;
  name: string;
  type?: string;
  course?: string;
  category: "holiday" | "deadline" | "exam" | "course";
  link?: string;
  component?: string;
  componentDisplay?: string;
  startTime?: string;
  endTime?: string;
  academicGroups?: string[];
  repeats?: boolean;
  day?: number;
  startDate?: Date;
  endDate?: Date;
  dbId?: string;
  venue?: string;
}

interface CustomCalendarProps {
  date: Date;
  view: "month" | "week";
  events: CalendarEvent[];
  className?: string;
  onEventClick?: (event: CalendarEvent) => void;
  repoCourses?: RepoCourse[];
  deadlineEvents?: CalendarEvent[];
  selectedEvent?: CalendarEvent | null;
  onEventDelete?: (event: CalendarEvent) => void;
  isEditorMode?: boolean;
}

const HOURS = Array.from({ length: 12 }, (_, i) => i + 8);

const CustomCalendar = ({
  date,
  view,
  events,
  className,
  onEventClick,
  repoCourses = [],
  deadlineEvents = [],
  selectedEvent,
  onEventDelete,
  isEditorMode = false,
}: CustomCalendarProps) => {
  const [calendarDays, setCalendarDays] = useState<Date[]>([]);

  useEffect(() => {
    if (view === "month") {
      const monthStart = startOfMonth(date);
      const monthEnd = endOfMonth(date);
      const startDate = startOfWeek(monthStart);
      const endDate = endOfWeek(monthEnd);
      const daysInMonth = eachDayOfInterval({
        start: startDate,
        end: endDate,
      });
      setCalendarDays(daysInMonth);
    } else {
      const weekStart = startOfWeek(date);
      setCalendarDays(Array.from({ length: 7 }).map((_, i) => addDays(weekStart, i)));
    }
  }, [date, view]);

  const getEventsForDay = (day: Date, includeTime: boolean = false) => {
    const dayEvents = events.filter((event) => {
      if (event.category !== "course") {
        return isSameDay(event.date, day);
      }
      // For course events, check if it's a repeating event for the weekday
      if (event.repeats && event.day !== undefined) {
        return getDay(day) === event.day && !isHoliday(day);
      }
      return isSameDay(event.date, day) && !isHoliday(day);
    });
    if (includeTime) {
      return dayEvents.sort((a, b) => {
        if (!a.startTime) return 1;
        if (!b.startTime) return -1;
        return a.startTime.localeCompare(b.startTime);
      });
    }
    return dayEvents;
  };

  const isHoliday = (day: Date) => {
    return events.some(event => 
      event.category === "holiday" && isSameDay(event.date, day)
    );
  };

  const getEventStyle = (event: CalendarEvent) => {
    switch (event.category) {
      case "holiday":
        return event.type === "university" ? "bg-red-900/60" : "bg-yellow-700/60";
      case "deadline":
        return "bg-blue-900/60";
      case "exam":
        return "bg-purple-900/60";
      case "course":
        if (event.course) {
          const courseNum = event.course.replace(/\D/g, '');
          const colorNum = parseInt(courseNum) % 5;
          switch (colorNum) {
            case 0: return "bg-green-900/70";
            case 1: return "bg-cyan-900/70";
            case 2: return "bg-indigo-900/70";
            case 3: return "bg-orange-900/70";
            case 4: return "bg-pink-900/70";
            default: return "bg-green-900/70";
          }
        }
        return "bg-green-900/70";
      default:
        return "bg-gray-800/60";
    }
  };

  // Get full course name (code+title) if course
  function getFullCourseName(courseCode: string | undefined) {
    if (!courseCode) return "";
    const course = repoCourses.find((c) => c.code === courseCode);
    return course ? `${course.code} - ${course.name}` : courseCode;
  }

  return (
    <div className={cn("custom-calendar", className)}>
      {view === "month" && (
        <div className="grid grid-cols-7 gap-1 text-center text-sm font-medium mb-1">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="py-2 bg-muted rounded-sm">{day}</div>
          ))}
        </div>
      )}
      {view === "month" ? (
        <div className="grid grid-cols-7 gap-1 auto-rows-fr">
          {calendarDays.map((day, i) => {
            const dayEvents = getEventsForDay(day);
            const isCurrentMonth = isSameMonth(day, date);
            return (
              <div
                key={i}
                className={cn(
                  "border border-border rounded-sm min-h-[120px] p-1",
                  !isCurrentMonth && "opacity-40",
                  "flex flex-col"
                )}
              >
                <div className={cn(
                  "text-xs font-medium p-1 rounded-full w-7 h-7 flex items-center justify-center",
                  isSameDay(day, new Date()) && "bg-primary text-primary-foreground"
                )}>
                  {format(day, "d")}
                </div>
                <div className="flex flex-col gap-1 mt-1 overflow-y-auto flex-grow">
                  {dayEvents.map((event, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "text-xs p-1.5 rounded cursor-pointer hover:brightness-110 transition-all",
                        getEventStyle(event)
                      )}
                      title={event.name}
                      onClick={() => onEventClick && onEventClick(event)}
                    >
                      <div className="truncate">
                        {event.category === "deadline" && event.course && (
                          <span className="font-bold">{event.course}: </span>
                        )}
                        {event.name}
                      </div>
                      {event.link && (
                        <a 
                          href={event.link} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="ml-1 shrink-0 inline-block"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        // Weekly view with hours
        <table className="min-w-full border border-border bg-dark-bg">
          <thead>
            <tr>
              <th className="w-14 px-2 py-1 border-b border-border text-xs bg-muted"></th>
              {calendarDays.map((day, i) => (
                <th key={i} className="border-b border-border px-2 py-1 text-xs bg-muted font-medium text-center">
                  {format(day, "EEE d")}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {/* Render hourly rows, each row = an hour from 8am to 7pm */}
            {HOURS.map((hour, hourIdx) => (
              <tr key={hour}>
                <td className="border-t border-border px-2 py-2 align-top text-xs text-right bg-background sticky left-0 z-10 w-14">
                  <span>
                    {hour > 12 ? hour - 12 : hour} {hour >= 12 ? "PM" : "AM"}
                  </span>
                </td>
                {/* For each day of week */}
                {calendarDays.map((day, colIdx) => {
                  // Gather all course events for this day that overlap with this hour box
                  const dayCourses = filterCourseEventsForDay(day, events);
                  const eventsForCell = dayCourses.filter(event => {
                    const [startH, startM, endH, endM] = getCourseTimeRange(event);
                    // event runs during this hour if start hour <= hour < end hour OR overlap
                    return (
                      (startH < hour && endH > hour) ||
                      (startH === hour) ||
                      (startH < hour + 1 && endH >= hour + 1)
                    );
                  });
                  return (
                    <td
                      key={colIdx}
                      className={cn(
                        "relative border-t border-border px-0.5 py-1 min-w-[110px] h-[60px] align-top bg-background"
                      )}
                    >
                      {eventsForCell.map((event, idx) => {
                        // Calculate event block vertical start and height
                        const [startH, startM, endH, endM] = getCourseTimeRange(event);
                        const eventStartPx = ((startM / 60) * 60); // from top of cell in px
                        const durationH = endH - startH + (endM - startM)/60;
                        const eventHeightPx = durationH * 60 || 60;
                        // If this event starts at this hour, render (otherwise skip, it will be rendered at its start hour cell)
                        if (startH !== hour) return null;
                        return (
                          <div
                            key={idx}
                            className={cn(
                              "absolute left-0 right-0 px-1 py-1 rounded-md cursor-pointer hover:brightness-105 transition-all flex flex-col",
                              getEventStyle(event)
                            )}
                            style={{
                              top: `${eventStartPx}px`,
                              height: `${eventHeightPx}px`,
                              zIndex: 10 + idx,
                            }}
                            onClick={() => onEventClick && onEventClick(event)}
                            title={event.name}
                          >
                            <div className="font-bold text-xs truncate">{event.course || ""} {event.componentDisplay}</div>
                            <div className="text-[11px]">{event.startTime} - {event.endTime}</div>
                          </div>
                        );
                      })}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* --- Unified Event Dialog for ALL events, with extra details --- */}
      <Dialog open={!!selectedEvent} onOpenChange={() => onEventClick && onEventClick(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <span className={cn(
                "w-3 h-3 rounded-full mr-2",
                selectedEvent && getEventStyle(selectedEvent)
              )}></span>
              {selectedEvent?.category &&
                (selectedEvent.category.charAt(0).toUpperCase() + selectedEvent.category.slice(1))} Details
            </DialogTitle>
          </DialogHeader>
          {selectedEvent && (
            <div className="space-y-4">
              {/* Name */}
              <div>
                <h4 className="text-sm font-semibold text-muted-foreground">Name</h4>
                <p>{selectedEvent.name}</p>
              </div>
              
              {/* Course Title and Groups */}
              {selectedEvent.category === "course" && (
                <>
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground">Course</h4>
                    <p>{getFullCourseName(selectedEvent.course)}</p>
                  </div>
                  {selectedEvent.academicGroups && selectedEvent.academicGroups.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold text-muted-foreground">Academic Groups</h4>
                      <p>
                        {selectedEvent.academicGroups.join(", ")}
                      </p>
                    </div>
                  )}
                </>
              )}

              {/* For deadline, show course and due time */}
              {selectedEvent.category === "deadline" && (
                <>
                  {selectedEvent.course && (
                    <div>
                      <h4 className="text-sm font-semibold text-muted-foreground">Course</h4>
                      <p>{getFullCourseName(selectedEvent.course)}</p>
                    </div>
                  )}
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground">Submission Time</h4>
                    <p>
                      {selectedEvent.startTime
                        ? selectedEvent.startTime
                        : "—"}
                    </p>
                  </div>
                </>
              )}

              {/* Holiday, type field */}
              {selectedEvent.category === "holiday" && selectedEvent.type && (
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground">Type</h4>
                  <p>{selectedEvent.type === "university" ? "University Holiday" : "Restricted Holiday"}</p>
                </div>
              )}
              
              {/* Course details */}
              {selectedEvent.category === "course" && (
                <>
                  {selectedEvent.component && (
                    <div>
                      <h4 className="text-sm font-semibold text-muted-foreground">Component</h4>
                      <p>{selectedEvent.component}</p>
                    </div>
                  )}
                  
                  {selectedEvent.startTime && selectedEvent.endTime && (
                    <div>
                      <h4 className="text-sm font-semibold text-muted-foreground">Time</h4>
                      <p>{selectedEvent.startTime} - {selectedEvent.endTime}</p>
                    </div>
                  )}

                  {selectedEvent.venue && (
                    <div>
                      <h4 className="text-sm font-semibold text-muted-foreground">Venue</h4>
                      <p>{selectedEvent.venue}</p>
                    </div>
                  )}
                  
                  {selectedEvent.repeats !== undefined && (
                    <div>
                      <h4 className="text-sm font-semibold text-muted-foreground">Repeats Weekly</h4>
                      <p>{selectedEvent.repeats ? "Yes" : "No"}</p>
                    </div>
                  )}
                </>
              )}
              
              {/* Date */}
              {selectedEvent.date && (
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground">Date</h4>
                  <p>{format(selectedEvent.date, "EEEE, MMMM d, yyyy")}</p>
                </div>
              )}
              
              {/* Resource */}
              {selectedEvent.link && (
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground">Resource</h4>
                  <a 
                    href={selectedEvent.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:underline flex items-center"
                  >
                    View Resource <ExternalLink className="h-3 w-3 ml-1" />
                  </a>
                </div>
              )}

              {/* Delete button for editor mode/course/holiday/exam (not for legacy) */}
              {isEditorMode && (["course", "holiday", "exam"].includes(selectedEvent.category)) && selectedEvent.dbId && onEventDelete && (
                <div className="flex justify-end">
                  <Button
                    variant="destructive"
                    onClick={() => {
                      onEventDelete(selectedEvent);
                      if (onEventClick) onEventClick(null);
                    }}
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Delete Event
                  </Button>
                </div>
              )}

              <div className="flex justify-end">
                <Button onClick={() => onEventClick && onEventClick(null)}>Close</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Helper: get course time slot (start hour/min, end hour/min) for vertical stretching
const getCourseTimeRange = (event: CalendarEvent) => {
  if (!event.startTime || !event.endTime) return [8, 0, 9, 0]; // default slot
  const [startH, startM] = event.startTime.split(":").map(Number);
  const [endH, endM] = event.endTime.split(":").map(Number);
  return [startH, startM, endH, endM];
};

// Helper: filter course events for a specific day
const filterCourseEventsForDay = (day: Date, events: CalendarEvent[]) => {
  return events.filter(event => {
    if (event.category !== "course") return false;
    if (event.repeats) {
      // Repeating: must fall on same weekday and within start/end date if provided
      const validDay = event.day !== undefined && getDay(day) === event.day;
      let withinDates = true;
      if (event.startDate && event.endDate) {
        withinDates = isWithinInterval(day, { start: event.startDate, end: event.endDate });
      }
      return validDay && withinDates;
    } else {
      // Non-repeating: match the date
      return isSameDay(event.date, day);
    }
  });
};

export default CustomCalendar;
