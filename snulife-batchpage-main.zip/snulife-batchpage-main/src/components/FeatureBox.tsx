
import React from 'react';
import { ArrowRight } from 'lucide-react';

type FeatureBoxProps = {
  title: string;
  description: string;
  gradientClass: string;
  number: string;
  href: string;
};

const FeatureBox: React.FC<FeatureBoxProps> = ({
  title,
  description,
  gradientClass,
  number,
  href,
}) => {
  return (
    <div className={`feature-box ${gradientClass}`}>
      <div>
        <span className="feature-number">{number}</span>
        <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
        <p className="text-white/80 text-sm leading-relaxed">{description}</p>
      </div>
      <div className="mt-4">
        <a href={href} className="explore-button group">
          Explore
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </a>
      </div>
    </div>
  );
};

export default FeatureBox;
