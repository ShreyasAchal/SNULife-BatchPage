
export interface IssueTicket {
  id: string;
  ticket_number: string;
  title: string;
  description: string;
  category: string;
  course: string;
  status: string;
  student_name: string;
  created_at: string;
  closed_at: string | null;
  cr_remarks: string | null;
  is_read: boolean;
  requested_response_time: string | null;
  image_url?: string | null;
}
